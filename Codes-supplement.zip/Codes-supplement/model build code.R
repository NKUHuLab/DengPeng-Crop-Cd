library(xlsx)
library(readxl)
library(hydroGOF)
library(randomForest)
library(ggplot2)
library(circlize)
library(RColorBrewer)
library(dplyr)
library(randomForestExplainer)
library(pdp)
library(tcltk)
library(patchwork)
library(raster)
library(ggbreak)
library(reshape2)
library(grid)
library(ggpointdensity)
library(ggsci)
library(openxlsx)
library(writexl)
library(caret)
library(igraph)
library(rfPermute)
library(plspm)

setwd('D:/master/project ing/soil plant')
data<-read.xlsx('paper/data_Cd.xlsx',2)
coor <- data[,4:5]
###add data value
soil <- c('TN','AN','TP','AP','AK','SOM','CEC')
Soil_wb <- createWorkbook()
for (i in 1:length(soil)){
  addWorksheet(Soil_wb,sheetName = soil[i])
}
for (i in 1:length(soil)){
  soil_data <- raster(paste0('paper/China predict/soil/',soil[i],'/',soil[i],'.tif'))
  soil_value <- as.data.frame(raster::extract(soil_data, coor))
  writeData(Soil_wb, sheet = i, soil_value)
}
saveWorkbook(Soil_wb, "paper/data add/data add wheat.xlsx", overwrite = TRUE)



################################################################################
setwd('D:/master/project ing/soil plant/paper')
label<-c('Rice Grain','Rice Root','Wheat Grain','Wheat Root')

###import data(python one-hot Python)
Data_wb <- createWorkbook()
for (i in 1:length(label)){
  addWorksheet(Data_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  dataset <- read.xlsx('model build/data.xlsx', i)
  dmy <- dummyVars(" ~ .", data = dataset)
  trdata <- data.frame(predict(dmy, newdata = dataset))
  #colnames(trdata)[17:19] <- c('Type1','Type2','Type3')
  writeData(Data_wb, sheet = i, trdata)
}
saveWorkbook(Data_wb, "model build/Python/data.xlsx", overwrite = TRUE)

####build model
setwd('D:/master/project ing/soil plant/paper')
label<-c('Rice Grain','Wheat Grain')

###train&important
Train_predict_wb <- createWorkbook()
Importance_wb <- createWorkbook()
for (i in 1:length(label)){
  addWorksheet(Train_predict_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  addWorksheet(Importance_wb,sheetName = label[i])
}

rf.list<-list()
for (i in 1:length(label)){
  dataset <- read.xlsx('model build/data.xlsx', i)
  colnames(dataset)[length(dataset[1,])]<-'index'
  dataset$index<-as.numeric(dataset$index)

  rf.list[[label[i]]]<-local({
    randomForest(index~. , data = dataset, 
                 ntree=500,mtry=3,
                 proximity = T,
                 importance = T)})
  rf<-rf.list[[label[i]]]
  p <- predict(rf, dataset)
  a <- dataset[,length(dataset[1,])]
  predict <- cbind(a,p)
  imp <- as.data.frame(rf$importance)
  imp[,3] <- rownames(imp)
  colnames(imp) <- c("MSE","Node","variables")
  
  writeData(Train_predict_wb, sheet = i, predict)
  writeData(Importance_wb, sheet = i, imp)
  print(i)
}
save(rf.list,file='model build/Rda/rflist.rda')
saveWorkbook(Train_predict_wb, "model build/Train_predict.xlsx", overwrite = TRUE)
saveWorkbook(Importance_wb, "model build/Importance.xlsx", overwrite = TRUE)

###test
#R2 importance
Test_predict_wb <- createWorkbook()
Test_predict_10fold_wb <- createWorkbook()
Train_predict_10fold_wb <- createWorkbook()
importance_predict_10fold_wb <- createWorkbook()
for (i in 1:length(label)){
  addWorksheet(Test_predict_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  addWorksheet(Test_predict_10fold_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  addWorksheet(Train_predict_10fold_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  addWorksheet(importance_predict_10fold_wb,sheetName = label[i])
}
for (i in 1:length(label)){
  dataset <- read.xlsx('model build/data.xlsx', i)
  colnames(dataset)[length(dataset[1,])]<-'index'
  dataset$index<-as.numeric(dataset$index)
  
  set.seed(12345);disorder <- sample(length(dataset[,2]),replace=F)
  fold_num <- floor(length(dataset[,2])/10)
  
  n_test <- data.frame()
  n_train <- data.frame()
  n_importance <- data.frame(MSX <- c(rep(0, times = (length(dataset[1,])-1))), 
                    NP<- c(rep(0, times = (length(dataset[1,])-1))))
  predict <- data.frame()
  for (k in 1:10){
    o <- disorder[(fold_num*(k-1)+1):(fold_num*k)]
    rf.data <- dataset[-o,]
    rf <- randomForest(index~. , data = rf.data, 
                       ntree=500,mtry=3,
                       proximity = F,
                       importance = T)
    p <- predict(rf, dataset[o,])
    a <- dataset[o,length(dataset[1,])]
    p_train <- predict(rf, rf.data)
    a_train <- rf.data[,length(dataset[1,])]
    imp <- as.data.frame(rf$importance)

    r2 <- cor(p,a)
    rm <- rmse(p,a)
    predict <- rbind(predict,cbind(a,p))
    
    n_test <- rbind(n_test,cbind(r2,rm))
    r2_train <- cor(p_train,a_train)
    rm_train <- rmse(p_train,a_train)
    n_train <- rbind(n_train,cbind(r2_train,rm_train))
    n_importance <- imp + n_importance
  }
  colnames(n_train) <- c('r2','rm')
  n_importance <- n_importance/10
  n_importance[,3] <- rownames(imp)
  colnames(n_importance) <- c("MSE","Node","variables")
  
  writeData(Test_predict_wb, sheet = i, predict)
  writeData(Test_predict_10fold_wb, sheet = i, n_test)
  writeData(Train_predict_10fold_wb, sheet = i, n_train)
  writeData(importance_predict_10fold_wb, sheet = i, n_importance)
  print(paste0(label[i],' R2:', mean(n_test$r2)))
}
saveWorkbook(Test_predict_wb, "model build/Test_predict.xlsx", overwrite = TRUE)
saveWorkbook(Test_predict_10fold_wb, "model build/Test_predict_10fold.xlsx", overwrite = TRUE)
saveWorkbook(Train_predict_10fold_wb, "model build/Train_predict_10fold.xlsx", overwrite = TRUE)
saveWorkbook(importance_predict_10fold_wb, "model build/Importance_10fold.xlsx", overwrite = TRUE)

###R2 distribution
#https://zhuanlan.zhihu.com/p/461179154 geom_flat_violin/code (geom_flat_violin code)
data = read.xlsx('model build/Plot/R2 distribution/R2 distribution.xlsx',1)
data$Index <- factor(data$Index,
                       level=c('Rice Grain','Rice Root','Wheat Grain','Wheat Root'),ordered=TRUE)
ggplot(data, aes(x=Index,y=r2)) +
  geom_flat_violin(aes(fill=Index),position = position_nudge(x=.325),color='black') +
  geom_jitter(aes(color=Index),width = 0.15) +
  geom_boxplot(width=.15,position = position_nudge(x=0.25),fill='white',size=0.5)+
  scale_fill_manual(values=c('#944E21', '#92CD93', '#EDC0CA', '#3972B8'))+
  labs(x='Index',y='R2',title='Cd Accumulation-Rice/Wheat')+
  scale_y_continuous(limits=c(0.5,1), breaks = seq(0.5, 1, 0.1))+
  theme_light()
ggsave(filename = 'model build/Plot/R2 distribution/R2 distribution.pdf',width=8,height=6)

###scatter plot
setwd('D:/master/project ing/soil plant/paper')
rfplot<-list()
scale <- c(5, 35, 5, 20)

for (i in 1:length(label)){
  data<-read.xlsx('model build/Plot/scatter/Test_predict.xlsx',i)
  data<-as.data.frame(lapply(data,as.numeric))
  data$title <- label[i]
  rmse_test <- rmse(data$a, data$p)
  r2 <- cor(data$a, data$p)
  
  rfplot[[label[i]]] <- local({
      ggplot(data, aes(x=a,y=p))+
      geom_pointdensity(size=5,adjust=1,show.legend = TRUE)+
      #geom_hex(bins = 50)+
      scale_colour_gradientn(colours=c("darkblue","blue","#0092FF","#00FF92","#49FF00",
                                       "#FFDB00","#FF0000","red","darkred"))+
      geom_abline(intercept=0,slope=1,size=2,color='#348498', linetype=2)+
      geom_smooth(method = "lm", formula = y ~ x, color = "black") +
      scale_x_continuous(limits=c(0,scale[i]))+
      scale_y_continuous(limits=c(0,scale[i]))+
      labs(x="Observation", y="Prediction")+
      annotate('text', x=scale[i]/5, y=scale[i]/5*4.5, label=paste0('R2=', round(r2,3)), size=8)+
      annotate('text', x=scale[i]/5, y=scale[i]/5*4, label=paste0('RMSE=', round(rmse_test,3)), size=8)+
      facet_grid( ~title, drop=TRUE,scale="free", space="free_x")+
      theme_bw()+
      theme(axis.line=element_line(color='black'),
            axis.ticks.length=unit(0.5,'line'))+
      theme(axis.text=element_text(colour='black',size=20),
            axis.title=element_text(colour='black',size=25))+
      theme(legend.position = c(0.98,0), legend.justification = c(1,0))+
      theme(legend.text = element_text(size = 15))+
      theme(legend.title=element_text(size=20))+
      theme(strip.background = element_rect(fill=c("#D2D2D2")))+
      theme(strip.text = element_text(size = 25,face = 'bold',colour = "#328BBF"))+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
  })
}
rfp<-rfplot[[1]]
for (i in 2:4){
  rfp<-rfp+rfplot[[i]]
}
rfp<-rfp+plot_layout(ncol=2)
print(rfp)
ggsave(filename = 'model build/Plot/scatter/scatter.pdf',width=14.5,height=15.5)

##############Importance analysis#####################
load(file='model build/Rda/rflist.rda')
md<-list()
mi<-list()
for (i in 1:length(label)){
  data <- read.xlsx('model build/data.xlsx', i)
  colindex <- c(colnames(data))
  colindexf<-factor(colindex[-length(colindex)],levels=colindex[-length(colindex)])

  rf<-rf.list[[i]]
  min_depth_frame<-min_depth_distribution(rf)
  md[[label[i]]]<-min_depth_frame
  im_frame<-measure_importance(rf)
  im_frame[4]<-im_frame[4]/max(im_frame[4])
  im_frame[5]<-im_frame[5]/max(im_frame[5])
  mi[[label[i]]]<-im_frame
  print(i)
}
save(md,mi,file='model build/Rda/multi-importance.rda')
###multi-wayplot
load(file='model build/Rda/rflist.rda')
load(file='model build/Rda/multi-importance.rda')
mdplot<-list()
miplot<-list()
for (i in 1:length(label)){
  print(i)
  min_depth_frame<-md[[i]]
  mdplot[[label[i]]]<-local({
    min_depth_frame=min_depth_frame
    plot_min_depth_distribution(min_depth_frame,k=10)+
      theme(axis.text=element_text(colour='black',size=10),
            axis.title=element_text(colour='black',size=15))+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
      theme(legend.key.size = unit(0.5,'line'),legend.title = element_text(size=rel(0.6)),
            legend.text = element_text(size=rel(0.5)))
  })
  ggsave(paste0('model build/Plot/Importance/mp_',label[i],'.pdf'),width=7,height=7)
  
  im_frame=mi[[i]]
  im_frame$p_value<-im_frame$p_value/5
  miplot[[label[i]]]<-local({
  im_frame=im_frame
  plot_multi_way_importance(im_frame, x_measure = "mse_increase",
                            y_measure = "node_purity_increase",
                            size_measure = "p_value", no_of_labels = 7)+
    theme(axis.text=element_text(colour='black',size=10),
          axis.title=element_text(colour='black',size=15))+
    theme(axis.line=element_line(color='black'),
          axis.ticks.length=unit(0.5,'line'))+
    labs(x="MSE increase", y="Node Purity Increase")+
    theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
    coord_fixed(ratio=1)+
    theme(legend.position=c(0.1,0.8))
  })
 ggsave(paste0('model build/Plot/Importance/im_',label[i],'.pdf'),width=5,height=5)
}
save(mdplot,miplot,file='model build/Rda/importanceplot.rda')

####PDP
i = 3
dataset <- read.xlsx('model build/data.xlsx', i)
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index <- as.numeric(dataset$index)
rf <- randomForest(index~. , data = dataset, 
                   ntree=500,mtry=3,
                   proximity = F,
                   importance = T)
partial(rf, pred.var = "MAP", plot = TRUE, rug = TRUE)
partial(rf, pred.var = c("OM", "Cd"), grid.resolution = 40,
        plot = TRUE, chull = TRUE, progress = "text")

###Grain Cd积累数据分布
data = read.xlsx('model build/Plot/data distribution/Grain.xlsx', 1)
data$Type <- factor(data$Type,
                     level=c('Rice Grain','Wheat Grain'),ordered=TRUE)
ggplot(data, aes(x=Type,y=label)) +
  geom_boxplot()+
  geom_jitter(width=0.2,size=1)+
  scale_fill_manual(values=c('#944E21', '#92CD93'))+
  labs(x='Type',y='Label',title='Grain Data Distribution')+
  scale_y_continuous(limits=c(0,5), breaks = seq(0, 5, 1))+
  theme(axis.text=element_text(colour='black',size=15),
        axis.title=element_text(colour='black',size=20))+
  theme_bw()
ggsave(filename = 'model build/Plot/data distribution/Grain distribution.pdf',width=8,height=6)

###PLS-MP
setwd('D:/master/project ing/soil plant/paper')
data <- read.xlsx('model build/PLS-MP/PLS_data.xlsx',1)
Climate <- c(0, 0, 0, 0)
Property <- c(1, 0, 0, 0)
Cd <-c (1, 1, 0, 0)
Label <- c(1, 1, 1, 0)
df_path <- rbind(Climate,Property,Cd,Label)
innerplot(df_path)
df_blocks = list(1:2,3:7,8,9)
df_modes = rep("A", 4)
df_pls = plspm(data, df_path, df_blocks, modes = df_modes,scaled = F, boot.val = TRUE)
summary(df_pls)
df_pls$gof
innerplot(df_pls)

###SEM
setwd('D:/master/project ing/soil plant/paper')
data <- read.xlsx('model build/PLS-MP/PLS_data.xlsx',1)
model <- '
          label ~ MAT
          label ~ MAP
          label ~ pH
          label ~ TP
          label ~ TN
          label ~ OM
          label ~ CEC
          label ~ Cd
          pH ~~ MAT + MAP
          TN ~~ MAT + OM + CEC
          CEC ~~ MAT + MAP
          Cd ~~ Cd
'
data=scale(data,center=TRUE,scale=TRUE)
fit_model <- sem(model, data=data)
summary(fit_model, standardized = TRUE)
fitmeasures(fit_model,c("chisq", "df", "gfi", "rmsea", "srmr"))
semPaths(fit_model,"std",edge.label.cex=0.8,#字体
         fade=FALSE, layout = "spring",#布局
         optimizeLatRes = FALSE, residuals = FALSE)













