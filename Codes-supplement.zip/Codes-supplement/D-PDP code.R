library("raster")
setwd("D:/master/project ing/plant-NP/model0118/R rf for plant")
r = raster("data/nc_3B42.20060101.03.7A.HDF.Z.ncml.nc")

library(xlsx)
library(readxl)
library(openxlsx)
library(writexl)
library(randomForest)
library(pheatmap)
library(hydroGOF)
library(randomForest)
library(ggplot2)
library(circlize)
library(RColorBrewer)
library(dplyr)
library(randomForestExplainer)
library(pdp)
library(tcltk)
library(patchwork)
library(raster)
library(ggbreak)
library(reshape2)
library(grid)
library(ggpointdensity)
library(ggsci)
library(openxlsx)
library(writexl)
library(caret)
library(igraph)
library(plspm)
library(reshape2)
library(data.table)
library(tidyverse)
##############################
### Dry Weight TC&Zeta&Size###
##############################
###color
plot_col <- function (nlev, col) {
  plot(x = c(1, (nlev + 1)), y = c(1, 2),
       xaxs = 'i', yaxs = 'i', xaxt = 'n', yaxt = 'n', type = 'n', ann = F)
  rect(xleft = 1:nlev,
       ybottom = rep(0, (nlev + 1)),
       xright = 2:(nlev + 1),
       ytop = rep(2, (nlev + 1)),
       col = col, border = 1)
  par(new = T)
  plot(x = c(1, (nlev + 1)), y = c(1, 2),
       xaxs = 'i', yaxs = 'i', xaxt = 'n', yaxt = 'n', type = 'n', ann = F)
}
colors <- c('blue', "white",'red')
RB <- colorRampPalette(colors = colors)
col <- RB(nlev)
plot_col(nlev, col)
#Rice-pH&Cd
setwd("C:/Users/admin/Desktop")
model_data <- read.xlsx('soil Cd/data.xlsx', 3)
rf <- randomForest(label~. , data = model_data, 
                   ntree=500,mtry=3,
                   proximity = T,
                   importance = T)
data_pdp <- read.xlsx('soil Cd/data.xlsx', 3)
frame_all <- data.frame()
for (i in seq(10,30,0.2)){
  data_pdp$MAT <- i
  for (n in seq(0,2000,20)){
    data_pdp$MAP <- n
    p <- predict(rf, data_pdp)
    p_value <- mean(p)
    frame <- cbind(i,n,p_value)
    frame_all <- rbind(frame_all, frame)
  }
  print(i)
}
frame_all <- as.data.frame(frame_all)
re_mat <- frame_all[1:101, 3]
for (i in 2:101){
  p <- frame_all[(1+(i-1)*101):(101*i),3]
  re_mat <- cbind(p, re_mat)
}
###heat map
"filled.contour(re_mat, 
               #color.palette = RB,
               plot.axes = contour(re_mat,add=T),
               #plot.axes = list(axis(1,seq(0, 2, by = 0.25),c('0','0.25','0.5','0.75','1.0','1.25',
               #                                              '1.5','1.75','2.0'),
               #               axis(2,seq(4, 9, by = 0.5),c('9.0','8.5','8.0','7.5','7.0','6.5',
               #                                          '6.0','5.5','5.0','4.5','4.0')))),
               plot.title = title(main = 'Wheat MAT-MAP', cex.main = 2))
ggsave(filename = 'soil Cd/PLOT/Rice Cd-pH.pdf',width=4.72,height=5.56)"

###line plot
line_data <- as.data.frame(re_mat)
line_data[,102]<-0
line_data[102,]<-0
for (i in 1:101){
  line_data[102,i] <- mean(line_data[1:101,i])
}
row_value <- data.frame()
row_value[1:102,1] <- 0
for (i in 1:101){
  row_value <- line_data[1:102,i]+row_value
}
row_value <- row_value/101
line_data[,102] <- row_value[,1]

Xaxis <- data.frame()
Xaxis[1:101,1] <- c(1:101)
Xaxis[1:101,2] <- t(line_data[102,1:101])
colnames(Xaxis) <- c('X', 'Y')
Yaxis <- data.frame()
Yaxis[1:101,1] <- c(1:101)
Yaxis[1:101,2] <- line_data[1:101,102]
colnames(Yaxis) <- c('X', 'Y')

#plot
ggplot(Xaxis, aes(X,Y))+
  geom_line(linewidth=1)+
  theme_bw()
ggsave(filename = 'soil Cd/PLOT/Wheat MAT-MAP X.pdf',width=4.72,height=2)

ggplot(Yaxis, aes(X,Y))+
  geom_line(linewidth=1)+
  theme_bw()
ggsave(filename = 'soil Cd/PLOT/Wheat MAT-MAP Y.pdf',width=4.72,height=2)



###China predict
setwd("C:/Users/admin/Desktop")
###rice coor
wheat <- raster('soil Cd/crop map/data/CHN_Wheat_2015.tif')
plot(wheat)
rice_frame <- as.data.frame(wheat, xy=T)
coor <- na.omit(as.data.frame(wheat, xy=T))
coor <- coor[rowSums(coor==0)==0,]
coor <- coor[,-3]


























