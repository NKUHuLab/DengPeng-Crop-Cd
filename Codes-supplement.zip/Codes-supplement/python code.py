# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 09:53:39 2023

@author: Deng Peng
"""

from sklearn.ensemble import RandomForestRegressor
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import ShuffleSplit
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tqdm import tqdm,trange
import random
from gplearn.genetic import SymbolicRegressor
import graphviz

def scatter_loss_plot():
    plt.subplot(1,2,1)
    plt.ylim(-1,1)
    plt.xlim(-1,1)
    plt.plot(y_test[colnames[0]],y_test_pred[0],'.')

    
    plt.subplot(1,2,2)
    plt.ylim(-1,1)
    plt.xlim(-1,1)
    plt.plot(y_train[colnames[0]],y_train_pred[0],'.')

    
def rmse(obs,pre):
    return np.sqrt(mean_squared_error(obs, pre))
    
def caculate_cor():
    global r_test,r_train,y_test_pred,y_train_pred,rmse_test,rmse_train
    y_test_pred=pd.DataFrame(model.predict(x_test).reshape(y_test.shape),index=test_index)
    r_test=np.corrcoef(y_test_pred[0],y_test[colnames[0]])
    y_train_pred=pd.DataFrame(model.predict(x_train).reshape(y_train.shape),index=train_index)
    r_train=np.corrcoef(y_train_pred[0],y_train[colnames[0]])
    rmse_test=rmse(y_test[colnames[0]],y_test_pred[0])
    rmse_train=rmse(y_train[colnames[0]],y_train_pred[0])
    

"""
rf-regression
"""
writer1=pd.ExcelWriter('all-rf-op.xlsx')
writer2=pd.ExcelWriter('all-rf-cor.xlsx')
writer3=pd.ExcelWriter('all-rf-imp.xlsx')
writer4=pd.ExcelWriter('all-pre.xlsx')
writer5=pd.ExcelWriter('all-val.xlsx')
names = list(('R-CGrain','R-CRoot','W-CGrain','W-CRoot'))

for i in trange(0,4):
    frame=pd.read_excel('data.xlsx',sheet_name=i)
    random.seed(1234)
    
    n=frame.shape[1]
    val=random.sample(range(0,len(frame)),5)
    model_index=list(frame.index)
    for j in val:
        model_index.remove(j)
    valdata=frame.loc[val,:]
    val_x=valdata.iloc[:,0:(n-1)]
    val_y=valdata.iloc[:,(n-1):]
    frame=frame.loc[model_index,:]
    x_data=frame.iloc[:,0:(n-1)]
    #x_data=frame[globals()['colindex'+str(i)]]
    x_data.index=range(len(x_data))
    y_data=frame.iloc[:,(n-1):]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    o=[]
    imp=[]
    model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
                                max_features=3#,min_samples_leaf=2
                                )
    #with tqdm(total=10) as pbar:
    for train_index , test_index in ss.split(x_data,y_data):
        x_train=x_data.iloc[train_index,:]
        x_train.columns=x_names
        
        y_train=y_data.iloc[train_index,:]
        
        x_test=x_data.iloc[test_index,:]
        x_test.columns=x_names
    
        y_test=y_data.iloc[test_index,:]
        model.fit(x_train,np.array(y_train).ravel())
        val_one=model.predict(val_x)
        vallist.append(val_one.T)
        #pre_one=model.predict(predf)
        #prelist.append(pre_one.T)
        caculate_cor()
        corlist_train.append(r_train[1,0])
        corlist_test.append(r_test[1,0])
        rmsel_train.append(rmse_train)
        rmsel_test.append(rmse_test)
       # scatter_loss_plot()
        o.append(y_train[colnames[0]])
        o.append(y_train_pred[0])
        o.append(y_test[colnames[0]])
        o.append(y_test_pred[0])
        #pbar.update()           
        imp.append(model.feature_importances_)

    #plt.show()        
    cordf=pd.DataFrame({'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    
    print(np.corrcoef(np.array(np.mean(vresult.T)).ravel(),
                          np.array(val_y).ravel())[0,1])
    vresult['predict']=np.array(np.mean(vresult.T)).ravel()
    vresult['observe']=val_y
    vresult['error']=vresult['predict']-vresult['observe']

    #imp_df=pd.DataFrame(imp,columns=globals()['colindex'+str(i)])
    imp_df=pd.DataFrame(imp,columns=x_names)
    obs_pre_df.to_excel(writer1,sheet_name=names[i])
    cordf.to_excel(writer2,sheet_name=names[i])
    imp_df.to_excel(writer3,sheet_name=names[i])
    presult.to_excel(writer4,sheet_name=names[i])
    vresult.to_excel(writer5,sheet_name=names[i])
    
writer1.save()
writer2.save()
writer3.save()
writer4.save()
writer5.save()

'''
Symbolic regressor
'''
i = 1
frame=pd.read_excel('gp_data.xlsx',sheet_name=i)
X = frame.iloc[:, :-1]
y = frame.iloc[:, -1]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=2)

gp =SymbolicRegressor(population_size=5000,
                      generations=20,
                      tournament_size=20,
                      stopping_criteria=0.01,
                      const_range=(-10, 10),
                      init_depth=(2,6),
                      function_set=('add', 'sub', 'mul',"div",'sin','cos'),
                      random_state=0)
gp.fit(X_train,y_train)
print (gp._program)
y_predict = pd.DataFrame(gp.predict(X_test))
y_test = pd.DataFrame(y_test)
#p = pd.merge([y_test, y_predict])





'''
permutation test
'''
names = list(('R-CGrain','R-CRoot','W-CGrain','W-CRoot'))
writer1=pd.ExcelWriter('permutation.xlsx')

for i in trange(0,4):
    frame=pd.read_excel('data.xlsx',sheet_name=i)
    n=frame.shape[1]
    random.seed(i)
    val=random.sample(range(0,len(frame)),5)
    model_index=list(frame.index)
    for j in val:
        model_index.remove(j)
    #x_data=frame[globals()['colindex'+str(i)]]
    valdata=frame.iloc[val,:]
    val_x=valdata.iloc[:,0:(n-1)]
    val_y=valdata.iloc[:,(n-1):]
    frame=frame.iloc[model_index,:]
    x_data=frame.iloc[:,0:(n-1)]
    x_data.index=range(len(x_data))
    y_data=frame.iloc[:,(n-1):]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    r2_list=[]
    q2_list=[]
    model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
                                max_features=3#,min_samples_leaf=2
                                )
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]
            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:]
            
            for j in trange(5):
                for k in range(10):
                    random.seed(i+j+k)
                    per_index=np.random.choice(train_index,round((j+1)*0.2*len(x_train)),False)
                    y_train_per=y_train.copy()
                    for i_index in per_index:
                        y_train_per.loc[i_index,:]=np.random.uniform(-1,1)#######################################设置数据的范围
                    model.fit(x_train,np.array(y_train_per).ravel())
                    r2_list.append(
                        np.corrcoef(y_train.iloc[:,0],y_train_per.iloc[:,0])[0,1])
                    y_array=np.array(y_test).ravel()
                    rss=np.sum((y_array-model.predict(x_test))**2)                          
                    tss=np.sum((y_array-np.mean(y_array))**2)
                    q2=1-rss/tss
                    q2_list.append(q2)
                
            model.fit(x_train,np.array(y_train).ravel())
            r2_list.append(1)
            rss=np.sum((y_array-model.predict(x_test))**2)                          
            tss=np.sum((y_array-np.mean(y_array))**2)
            q2=1-rss/tss
            q2_list.append(q2)
            pbar.update() 
             
    perdf=pd.DataFrame({'r2':r2_list,'q2':q2_list})
    
    plt.ylim(-2,1)
    plt.xlim(0,1)
    plt.plot(perdf['r2'],perdf['q2'],'.')
    plt.show()
    perdf.to_excel(writer1,sheet_name=names[i])
writer1.save() 

