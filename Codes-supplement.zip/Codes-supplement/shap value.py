# -*- coding: utf-8 -*-
"""
Created on Tue Apr  4 22:52:11 2023

@author: admin
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pandas import read_csv
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from pandas.plotting import scatter_matrix   #绘制数值属性之间的相关性

from sklearn.preprocessing import OrdinalEncoder    #处理文本属性，将类别转成数字
from sklearn.preprocessing import OneHotEncoder     #将类别值转化为独热向量
from sklearn.base import BaseEstimator, TransformerMixin   
#自定义转换器添加组合后的属性，前者构造函数时避免*args和**kargs，后者得到fit_transform()方法
from sklearn.pipeline import Pipeline    #构造流水线使数据转换的步骤以正确的顺序进行
from sklearn.preprocessing import StandardScaler    #标准化的转换器
from sklearn.compose import ColumnTransformer       #需要对不同的列组(数值列、分类列)应用不同的transformer   
from sklearn.metrics import mean_squared_error    #mse均方误差，rmse均方根误差


from sklearn.model_selection import GridSearchCV    #网格搜索法
from sklearn.model_selection import RandomizedSearchCV    #随机搜索法
from sklearn.ensemble import RandomForestRegressor    #随机森林
from sklearn.model_selection import cross_val_score    #交叉验证
from sklearn import metrics
import joblib
import json
from sklearn.model_selection import cross_validate
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedShuffleSplit#分层抽样
# from keras.wrappers.scikit_learn import KerasRegressor
from pandas import DataFrame as df
import time
import xgboost
from xgboost import XGBRegressor
from sklearn.inspection import permutation_importance
import matplotlib.pyplot as plt

import shap

    
    
    
    
#Rice  
data=pd.read_excel('data_Cd.xlsx',sheet_name=0)
data.columns
g=pd.read_csv('Rice prediction data.csv')

attributes=['Site', 'Farmland', 'Sitein', 'pH', 'TN', 'TP', 'AK', 'OM', 'CEC', 'Cd']
x_train = data.iloc[:,0:10]
y_train = data.iloc[:,10]
model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
                                max_features=7#,min_samples_leaf=2
                                )
model.fit(x_train,y_train)
X=g[attributes]
model=model
start =time.time()
explainer = shap.Explainer(model)
shap_values = explainer(X)
end = time.time()
print('Running time: %s Seconds'%(end-start))


a=pd.DataFrame(shap_values.values)
a.columns=attributes
a.to_csv('Rice shap.csv')




#Wheat
data=pd.read_excel('data_Cd.xlsx',sheet_name=1)
data.columns
g=pd.read_csv('Wheat prediction data.csv')

attributes=['Site', 'Farmland', 'Sitein', 'pH', 'TN', 'TP', 'AK', 'OM', 'CEC', 'Cd']
x_train = data.iloc[:,0:10]
y_train = data.iloc[:,10]
model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
                                max_features=7#,min_samples_leaf=2
                                )
model.fit(x_train,y_train)
X=g[attributes]
model=model
start =time.time()
explainer = shap.Explainer(model)
shap_values = explainer(X)
end = time.time()
print('Running time: %s Seconds'%(end-start))


a=pd.DataFrame(shap_values.values)
a.columns=attributes
a.to_csv('Wheat shap.csv')












































