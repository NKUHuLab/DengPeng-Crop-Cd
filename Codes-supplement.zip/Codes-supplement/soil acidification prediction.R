library(xlsx)
library(readxl)
library(hydroGOF)
library(randomForest)
library(ggplot2)
library(circlize)
library(RColorBrewer)
library(dplyr)
library(randomForestExplainer)
library(pdp)
library(tcltk)
library(patchwork)
library(raster)
library(ggbreak)
library(reshape2)
library(grid)
library(ggpointdensity)
library(ggsci)
library(openxlsx)
library(writexl)
library(caret)
library(igraph)
library(rfPermute)
library(plspm)
library(ggalt)
library(ggsci)
###soil acidification prediction
###1980 data
setwd('D:/master/project ing/soil plant/paper/China predict/soil acidification')
soil <- read.xlsx('1980-1996/土壤理化性质.xlsx', 2)
county <- read.xlsx('1980-1996/剖面景观表.xlsx', 3)
df <- merge(county, soil, by ="Soil_ID")
write.xlsx(df,'data/soil property 1980.xlsx')

data_1980 <- read.xlsx('data/soil property 1980.xlsx',1)
###pH 整合(1980&2000)
pH_2000 <- read.xlsx('data/soil property 2000.xlsx', 1)
pH_1980_2000 <- merge(data_1980, pH_2000, by =c("country","province"))
pH_1980_2000 <- subset(pH_1980_2000, pH_1980_2000$pH > 0)
pH_1980_2000 <- pH_1980_2000[,c(1,2,4,5,6,7,8,14)]
colnames(pH_1980_2000)[3] <- 'city'
country_list <- unique(pH_1980_2000$country)
pH <- data.frame()
for (i in 1:length(country_list)){
  pH_one <- subset(pH_1980_2000, pH_1980_2000$country == country_list [i])
  pH_one <- arrange(pH_one, -pH_one[,7])
  pH_one <- pH_one[1,]
  pH <- rbind(pH,pH_one)
}
write.xlsx(pH,'data/pH_1980_2000.xlsx')

###TN整合(1980&2000)
TN_2000 <- read.xlsx('data/soil property 2000.xlsx', 2)
TN_1980_2000 <- merge(data_1980, TN_2000, by =c("country","province"))
TN_1980_2000 <- subset(TN_1980_2000, TN_1980_2000$TN > 0)
TN_1980_2000 <- TN_1980_2000[,c(1,2,4,5,6,7,9,14)]
colnames(TN_1980_2000)[3] <- 'city'
country_list <- unique(TN_1980_2000$country)
TN <- data.frame()
for (i in 1:length(country_list)){
  TN_one <- subset(TN_1980_2000, TN_1980_2000$country == country_list [i])
  TN_one <- arrange(TN_one, -TN_one[,7])
  TN_one <- TN_one[1,]
  TN <- rbind(TN,TN_one)
}
colnames(TN) <- c("country","province","city","Long","Lat","code","TN_1980","TN_2000" )
TN <- subset(TN, TN$TN_1980 < 5)
TN <- subset(TN, TN$TN_2000 < 5)
write.xlsx(TN,'data/TN_1980_2000.xlsx')

###OM整合(1980&2000)
OM_2000 <- read.xlsx('data/soil property 2000.xlsx', 3)
OM_1980_2000 <- merge(data_1980, OM_2000, by =c("country","province"))
OM_1980_2000 <- subset(OM_1980_2000, OM_1980_2000$OM > 0)
OM_1980_2000 <- OM_1980_2000[,c(1,2,4,5,6,7,12,14)]
colnames(OM_1980_2000)[3] <- 'city'
country_list <- unique(OM_1980_2000$country)
OM <- data.frame()
for (i in 1:length(country_list)){
  OM_one <- subset(OM_1980_2000, OM_1980_2000$country == country_list [i])
  OM_one <- arrange(OM_one, -OM_one[,7])
  OM_one <- OM_one[1,]
  OM <- rbind(OM,OM_one)
}
colnames(OM) <- c("country","province","city","Long","Lat","code","OM_1980","OM_2000" )
OM <- subset(OM, OM$OM_1980 < 100)
OM <- subset(OM, OM$OM_2000 < 100)
write.xlsx(OM,'data/OM_1980_2000.xlsx')


setwd("D:/master/project ing/soil plant/paper")
################################################################################
###dataset1  rice dataset(China crop distribution 2020)
crop <- raster('China predict/soil acidification/2010-2018/crop landuse/2015.tif')
plot(crop)
#提取rice分布点
crop_frame <- as.data.frame(crop, xy=T)
crop_frame <- subset(crop_frame, crop_frame[,3] == 1)
crop_frame <- crop_frame[,-3]
write.csv(crop_frame,'China predict/soil acidification/2010-2018/crop landuse/crop coor.csv', row.names=FALSE)

#提取全国县信息
setwd("D:/master/project ing/soil plant/paper")
x=sf::st_read('map/China map/省市县行政区划界线/县.shp')
plot(x)
country <- as.data.frame(x)
country <- country[,-c(3,5,7,8)]
colnames(country) <- c('code', 'country', 'province','city')
write.xlsx(country,'China predict/soil acidification/data/All country.xlsx')
#提取地理位置信息
setwd("D:/master/project ing/soil plant/paper")
crop_coor <- read.csv('China predict/soil acidification/2010-2018/crop landuse/crop coor.csv')
crop_country1 <- read.csv('China predict/soil acidification/data/output_try1.csv')
crop_country2 <- read.csv('China predict/soil acidification/data/output_try2.csv')
crop_country3 <- read.csv('China predict/soil acidification/data/output_try3.csv')
crop_country <- rbind(crop_country1,crop_country2,crop_country3)
crop_country <- crop_country[,c(4,5,6,8,9)]
colnames(crop_country) <- c('country','province','city','Long','Lat')
#write.csv(crop_country, 'China predict/soil acidification/data/output_try.csv')
crop_country_coor <- crop_country[,4:5]
#提取pH
pH_raster <- raster('China predict/soil acidification/2010-2018/1km-pH/pH/pH.tif')
pH_2010_frame <- as.data.frame(raster::extract(pH_raster, crop_country_coor))*0.01
colnames(pH_2010_frame) <- c('pH')
pH_2010 <- cbind(crop_country,pH_2010_frame)
pH_2010 <- na.omit(as.data.frame(pH_2010, xy=T))
#这一步需核对县名称一一对应
country_list <- read.csv('China predict/soil acidification/data/pH country name revise.csv')
country_list <- c(country_list$country.name)
pH_2010_value <- data.frame()
for (i in 1:length(country_list)){
  pH_2010_one <- subset(pH_2010, pH_2010$country == country_list[i])
  mean_value <- mean(pH_2010_one$pH)
  median_value <- median(pH_2010_one$pH)
  pH_2010_value <- rbind(pH_2010_value, cbind(country_list[i],mean_value,median_value))
}
colnames(pH_2010_value) <- c('mean','median')
pH_2010_value <- cbind(as.data.frame(country_list),pH_2010_value)
write.csv(pH_2010_value,'China predict/soil acidification/data/pH_2010_value.csv', row.names=FALSE)

#提取pH
pH_raster <- raster('China predict/soil acidification/2010-2018/90m-pH/pH/pH.tif')
pH_2010_frame <- as.data.frame(raster::extract(pH_raster, crop_country_coor))*0.01
colnames(pH_2010_frame) <- c('pH')
pH_2010 <- cbind(crop_country,pH_2010_frame)
pH_2010 <- na.omit(as.data.frame(pH_2010, xy=T))
#这一步需核对县名称一一对应
country_list <- read.csv('China predict/soil acidification/data/pH country name revise.csv')
country_list <- c(country_list$country.name)
pH_2010_value <- data.frame()
for (i in 1:length(country_list)){
  pH_2010_one <- subset(pH_2010, pH_2010$country == country_list[i])
  mean_value <- mean(pH_2010_one$pH)
  median_value <- median(pH_2010_one$pH)
  pH_2010_value <- rbind(pH_2010_value, cbind(country_list[i],mean_value,median_value))
  print(i)
}
colnames(pH_2010_value) <- c('country','mean','median')
pH_2010_value <- cbind(as.data.frame(country_list),pH_2010_value)
write.csv(pH_2010_value,'China predict/soil acidification/data/pH_2010_value.csv', row.names=FALSE)

#提取TN
TN_raster <- raster('China predict/soil acidification/2010-2018/TN/TN.tif')
TN_2010_frame <- as.data.frame(raster::extract(TN_raster, crop_country_coor))*10
colnames(TN_2010_frame) <- c('TN')
TN_2010 <- cbind(crop_country,TN_2010_frame)
TN_2010 <- na.omit(as.data.frame(TN_2010, xy=T))
#这一步需核对县名称一一对应 (先提取，一一核实后再重新提取)
country_list <- read.csv('China predict/soil acidification/data/TN country name revise.csv')
country_list <- c(country_list$country.name)
#country_list <- c(unique(TN$country))
TN_2010_value <- data.frame()
for (i in 1:length(country_list)){
  TN_2010_one <- subset(TN_2010, TN_2010$country == country_list[i])
  mean_value <- mean(TN_2010_one$TN)
  median_value <- median(TN_2010_one$TN)
  TN_2010_value <- rbind(TN_2010_value, cbind(country_list[i],mean_value,median_value))
  print(i)
}
colnames(TN_2010_value) <- c('country','mean','median')
TN_2010_value <- cbind(as.data.frame(country_list),TN_2010_value)
write.csv(TN_2010_value,'China predict/soil acidification/data/TN_2010_value.csv', row.names=FALSE)
#TN_table <- as.data.frame(table(TN_2010$country))
#write.csv(TN_table,'China predict/soil acidification/data/TN_table.csv', row.names=FALSE)

#提取OM
OM_raster <- raster('China predict/soil acidification/2010-2018/SOM/SOM.tif')
OM_2010_frame <- as.data.frame(raster::extract(OM_raster, crop_country_coor))*10
colnames(OM_2010_frame) <- c('OM')
OM_2010 <- cbind(crop_country,OM_2010_frame)
OM_2010 <- na.omit(as.data.frame(OM_2010, xy=T))
#这一步需核对县名称一一对应 (先提取，一一核实后再重新提取)
country_list <- read.csv('China predict/soil acidification/data/OM country name revise.csv')
country_list <- c(country_list$country.name)
#country_list <- c(unique(OM$country))
OM_2010_value <- data.frame()
for (i in 1:length(country_list)){
  OM_2010_one <- subset(OM_2010, OM_2010$country == country_list[i])
  mean_value <- mean(OM_2010_one$OM)
  median_value <- median(OM_2010_one$OM)
  OM_2010_value <- rbind(OM_2010_value, cbind(country_list[i],mean_value,median_value))
  print(i)
}
colnames(OM_2010_value) <- c('country','mean','median')
OM_2010_value <- cbind(as.data.frame(country_list),OM_2010_value)
write.csv(OM_2010_value,'China predict/soil acidification/data/OM_2010_value.csv', row.names=FALSE)
OM_table <- as.data.frame(table(OM_2010$country))
write.csv(OM_table,'China predict/soil acidification/data/OM_table.csv', row.names=FALSE)



###pH TN OM 配对到各个县
##Rice
#pH
setwd("D:/master/project ing/soil plant/paper")
country_list <- read.xlsx('China predict/soil acidification/data/All country.xlsx',1)
pH_data <- read.xlsx('China predict/soil acidification/data/pH_1980_2000_2010.xlsx',1)
pH_data <- subset(pH_data, pH_data$pH_2010>0)
pH_data_merge <- plyr::join(country_list, pH_data,by=c("country_revise","province_revise"))#河北桥东桥西
#第一步：按市为单位填补县级别的NA值(用已有的县级别数据的平均值填补NA)
city_list <- unique(pH_data_merge$city)
city <- data.frame()
for (i in 1:length(city_list)){
  city_one <- subset(pH_data_merge, pH_data_merge$city == city_list[i])
  if (length(city_list) > 0 ){
    city_one$pH[is.na(city_one$pH)] <- mean(city_one$pH,na.rm=T)
    city_one$pH_2000[is.na(city_one$pH_2000)] <- mean(city_one$pH_2000,na.rm=T)
    city_one$pH_2010[is.na(city_one$pH_2010)] <- mean(city_one$pH_2010,na.rm=T)
  } else{
    print(i)
  }
  city <- rbind(city, city_one)
}
#第二步：按省为单位填补市级别的NA值(用已有的市级别数据的平均值填补NA)
pH_data_merge <- city
province_list <- unique(pH_data_merge$province_revise)
province <- data.frame()
for (i in 1:length(province_list)){
  province_one <- subset(pH_data_merge, pH_data_merge$province_revise == province_list[i])
  if (length(province_list) > 0){
    province_one$pH[is.na(province_one$pH)] <- mean(province_one$pH,na.rm=T)
    province_one$pH_2000[is.na(province_one$pH_2000)] <- mean(province_one$pH_2000,na.rm=T)
    province_one$pH_2010[is.na(province_one$pH_2010)] <- mean(province_one$pH_2010,na.rm=T)
  } else{
    print(i)
  }
  province <- rbind(province, province_one)
}
country_pH_data <- province[,c(2,3,4,11,12,13)]
country_pH_data[,4:6] <- round(country_pH_data[,4:6],2)
country_pH_data[is.na(country_pH_data)] <- 0
write.csv(country_pH_data, 'China predict/soil acidification/data/All country pH.csv')
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_rice_average.csv')
data_information <- read.csv('China predict/soil acidification/data/rice coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country pH.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$pH_1980s_diff <- data_merge$pH_1980-data_merge$pH_2010
data_merge$pH_2000s_diff <- data_merge$pH_2000-data_merge$pH_2010#需进行约束1 (四分位距 - IQR)
pH_1980s_diff_0.25 <- quantile(data_merge$pH_1980s_diff, 0.25)#pH_1980
pH_1980s_diff_0.75 <- quantile(data_merge$pH_1980s_diff, 0.75)
pH_1980s_diff_IQR <- pH_1980s_diff_0.75 - pH_1980s_diff_0.25
pH_1980s_diff_LL <-  pH_1980s_diff_0.25 - pH_1980s_diff_IQR*1.5
pH_1980s_diff_UL <-  pH_1980s_diff_0.75 + pH_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_1980s_diff[i] < pH_1980s_diff_LL){
    data_merge$pH_1980s_diff[i] <- pH_1980s_diff_LL
  } else if (data_merge$pH_1980s_diff[i] > pH_1980s_diff_UL){
    data_merge$pH_1980s_diff[i] <- pH_1980s_diff_UL
  }else {
    data_merge$pH_1980s_diff[i] <- data_merge$pH_1980s_diff[i]
  }
}
pH_2000s_diff_0.25 <- quantile(data_merge$pH_2000s_diff, 0.25)#pH_2000
pH_2000s_diff_0.75 <- quantile(data_merge$pH_2000s_diff, 0.75)
pH_2000s_diff_IQR <- pH_2000s_diff_0.75 - pH_2000s_diff_0.25
pH_2000s_diff_LL <-  pH_2000s_diff_0.25 - pH_2000s_diff_IQR*1.5
pH_2000s_diff_UL <-  pH_2000s_diff_0.75 + pH_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_2000s_diff[i] < pH_2000s_diff_LL){
    data_merge$pH_2000s_diff[i] <- pH_2000s_diff_LL
  } else if (data_merge$pH_2000s_diff[i] > pH_2000s_diff_UL){
    data_merge$pH_2000s_diff[i] <- pH_2000s_diff_UL
  } else {
    data_merge$pH_2000s_diff[i] <- data_merge$pH_2000s_diff[i]
  }
}
data_merge$pH_1980_value <- data_merge$pH+data_merge$pH_1980s_diff
data_merge$pH_2000_value <- data_merge$pH+data_merge$pH_2000s_diff
data_merge$pH_2010_value <- data_merge$pH#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_pH <- max(data_merge[,21:23])
min_pH <- min(data_merge[,21:23])
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_1980_value[i] < min_pH){
    data_merge$pH_1980_value[i] <- min_pH
  } else if (data_merge$pH_1980_value[i] > max_pH){
    data_merge$pH_1980_value[i] <- max_pH
  }else {
    data_merge$pH_1980_value[i] <- data_merge$pH_1980_value[i]
  }
}
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_2000_value[i] < min_pH){
    data_merge$pH_2000_value[i] <- min_pH
  } else if (data_merge$pH_2000_value[i] > max_pH){
    data_merge$pH_2000_value[i] <- max_pH
  }else {
    data_merge$pH_2000_value[i] <- data_merge$pH_2000_value[i]
  }
}
pH_year <- c('pH_1980','pH_2000','pH_2010')
pH_year_wb <- createWorkbook()
for (i in 1:length(pH_year)){
  addWorksheet(pH_year_wb,sheetName = pH_year[i])
}
for (i in 1:length(pH_year)){
  output_data <- data_merge[,c(4:11,(25+i),13:18)]
  colnames(output_data)[9] <- 'pH'
  writeData(pH_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(pH_year_wb, "China predict/soil acidification/data/predict/pH/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s pH变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 1)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###rice pH predict
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/pH/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/pH/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/pH/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/pH/result_data.csv', row.names=FALSE)

means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/pH/Rice province average.csv', row.names=FALSE)

#TN
setwd("D:/master/project ing/soil plant/paper")
country_list <- read.xlsx('China predict/soil acidification/data/All country.xlsx',1)
TN_data <- read.xlsx('China predict/soil acidification/data/TN_1980_2000_2010.xlsx',1)#手动增加province_revise一列
TN_data <- subset(TN_data, TN_data$TN_2010>0)
TN_data_merge <- plyr::join(country_list, TN_data,by=c("country_revise","province_revise"))
#第一步：按市为单位填补县级别的NA值(用已有的县级别数据的平均值填补NA)
city_list <- unique(TN_data_merge$city)
city <- data.frame()
for (i in 1:length(city_list)){
  city_one <- subset(TN_data_merge, TN_data_merge$city == city_list[i])
  if (length(city_list) > 0 ){
    city_one$TN_1980[is.na(city_one$TN_1980)] <- mean(city_one$TN_1980,na.rm=T)
    city_one$TN_2000[is.na(city_one$TN_2000)] <- mean(city_one$TN_2000,na.rm=T)
    city_one$TN_2010[is.na(city_one$TN_2010)] <- mean(city_one$TN_2010,na.rm=T)
  } else{
    print(i)
  }
  city <- rbind(city, city_one)
}
#第二步：按省为单位填补市级别的NA值(用已有的市级别数据的平均值填补NA)
TN_data_merge <- city
province_list <- unique(TN_data_merge$province_revise)
province <- data.frame()
for (i in 1:length(province_list)){
  province_one <- subset(TN_data_merge, TN_data_merge$province_revise == province_list[i])
  if (length(province_list) > 0){
    province_one$TN_1980[is.na(province_one$TN_1980)] <- mean(province_one$TN_1980,na.rm=T)
    province_one$TN_2000[is.na(province_one$TN_2000)] <- mean(province_one$TN_2000,na.rm=T)
    province_one$TN_2010[is.na(province_one$TN_2010)] <- mean(province_one$TN_2010,na.rm=T)
  } else{
    print(i)
  }
  province <- rbind(province, province_one)
}
country_TN_data <- province[,c(2,3,4,10,11,12)]
country_TN_data[,4:6] <- round(country_TN_data[,4:6],3)
country_TN_data[is.na(country_TN_data)] <- 0
write.csv(country_TN_data, 'China predict/soil acidification/data/All country TN.csv')#手动补齐天津和吉林
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_rice_average.csv')
data_information <- read.csv('China predict/soil acidification/data/rice coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country TN.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$TN_1980s_diff <- data_merge$TN_1980-data_merge$TN_2010
data_merge$TN_2000s_diff <- data_merge$TN_2000-data_merge$TN_2010#需进行约束1 (四分位距 - IQR)
TN_1980s_diff_0.25 <- quantile(data_merge$TN_1980s_diff, 0.25)#TN_1980
TN_1980s_diff_0.75 <- quantile(data_merge$TN_1980s_diff, 0.75)
TN_1980s_diff_IQR <- TN_1980s_diff_0.75 - TN_1980s_diff_0.25
TN_1980s_diff_LL <-  TN_1980s_diff_0.25 - TN_1980s_diff_IQR*1.5
TN_1980s_diff_UL <-  TN_1980s_diff_0.75 + TN_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_1980s_diff[i] < TN_1980s_diff_LL){
    data_merge$TN_1980s_diff[i] <- TN_1980s_diff_LL
  } else if (data_merge$TN_1980s_diff[i] > TN_1980s_diff_UL){
    data_merge$TN_1980s_diff[i] <- TN_1980s_diff_UL
  }else {
    data_merge$TN_1980s_diff[i] <- data_merge$TN_1980s_diff[i]
  }
}
TN_2000s_diff_0.25 <- quantile(data_merge$TN_2000s_diff, 0.25)#TN_2000
TN_2000s_diff_0.75 <- quantile(data_merge$TN_2000s_diff, 0.75)
TN_2000s_diff_IQR <- TN_2000s_diff_0.75 - TN_2000s_diff_0.25
TN_2000s_diff_LL <-  TN_2000s_diff_0.25 - TN_2000s_diff_IQR*1.5
TN_2000s_diff_UL <-  TN_2000s_diff_0.75 + TN_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_2000s_diff[i] < TN_2000s_diff_LL){
    data_merge$TN_2000s_diff[i] <- TN_2000s_diff_LL
  } else if (data_merge$TN_2000s_diff[i] > TN_2000s_diff_UL){
    data_merge$TN_2000s_diff[i] <- TN_2000s_diff_UL
  } else {
    data_merge$TN_2000s_diff[i] <- data_merge$TN_2000s_diff[i]
  }
}
data_merge$TN_1980_value <- data_merge$TN+data_merge$TN_1980s_diff
data_merge$TN_2000_value <- data_merge$TN+data_merge$TN_2000s_diff
data_merge$TN_2010_value <- data_merge$TN#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_TN <- max(data_merge[,21:23])
min_TN <- min(data_merge[,21:23])
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_1980_value[i] < min_TN){
    data_merge$TN_1980_value[i] <- min_TN
  } else if (data_merge$TN_1980_value[i] > max_TN){
    data_merge$TN_1980_value[i] <- max_TN
  }else {
    data_merge$TN_1980_value[i] <- data_merge$TN_1980_value[i]
  }
}
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_2000_value[i] < min_TN){
    data_merge$TN_2000_value[i] <- min_TN
  } else if (data_merge$TN_2000_value[i] > max_TN){
    data_merge$TN_2000_value[i] <- max_TN
  }else {
    data_merge$TN_2000_value[i] <- data_merge$TN_2000_value[i]
  }
}
TN_year <- c('TN_1980','TN_2000','TN_2010')
TN_year_wb <- createWorkbook()
for (i in 1:length(TN_year)){
  addWorksheet(TN_year_wb,sheetName = TN_year[i])
}
for (i in 1:length(TN_year)){
  output_data <- data_merge[,c(4:12,(25+i),14:18)]
  colnames(output_data)[10] <- 'TN'
  writeData(TN_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(TN_year_wb, "China predict/soil acidification/data/predict/TN/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s TN变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 1)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###rice predict
#map data
TN_year <- c('TN_1980','TN_2000','TN_2010')
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/TN/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/TN/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/TN/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/TN/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/TN/Rice province average.csv', row.names=FALSE)

#OM
setwd("D:/master/project ing/soil plant/paper")
country_list <- read.xlsx('China predict/soil acidification/data/All country.xlsx',1)
OM_data <- read.xlsx('China predict/soil acidification/data/OM_1980_2000_2010.xlsx',1)#手动增加province_revise一列
OM_data <- subset(OM_data, OM_data$OM_2010>0)
OM_data_merge <- plyr::join(country_list, OM_data, by=c("country_revise","province_revise"))
#第一步：按市为单位填补县级别的NA值(用已有的县级别数据的平均值填补NA)
city_list <- unique(OM_data_merge$city)
city <- data.frame()
for (i in 1:length(city_list)){
  city_one <- subset(OM_data_merge, OM_data_merge$city == city_list[i])
  if (length(city_list) > 0 ){
    city_one$OM_1980[is.na(city_one$OM_1980)] <- mean(city_one$OM_1980,na.rm=T)
    city_one$OM_2000[is.na(city_one$OM_2000)] <- mean(city_one$OM_2000,na.rm=T)
    city_one$OM_2010[is.na(city_one$OM_2010)] <- mean(city_one$OM_2010,na.rm=T)
  } else{
    print(i)
  }
  city <- rbind(city, city_one)
}
#第二步：按省为单位填补市级别的NA值(用已有的市级别数据的平均值填补NA)
OM_data_merge <- city
province_list <- unique(OM_data_merge$province_revise)
province <- data.frame()
for (i in 1:length(province_list)){
  province_one <- subset(OM_data_merge, OM_data_merge$province_revise == province_list[i])
  if (length(province_list) > 0){
    province_one$OM_1980[is.na(province_one$OM_1980)] <- mean(province_one$OM_1980,na.rm=T)
    province_one$OM_2000[is.na(province_one$OM_2000)] <- mean(province_one$OM_2000,na.rm=T)
    province_one$OM_2010[is.na(province_one$OM_2010)] <- mean(province_one$OM_2010,na.rm=T)
  } else{
    print(i)
  }
  province <- rbind(province, province_one)
}
country_OM_data <- province[,c(2,3,4,10,11,12)]
country_OM_data[,4:6] <- round(country_OM_data[,4:6],2)
country_OM_data[is.na(country_OM_data)] <- 0
write.csv(country_OM_data, 'China predict/soil acidification/data/All country OM.csv')#手动补齐天津
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_rice_average.csv')
data_information <- read.csv('China predict/soil acidification/data/rice coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country OM.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$OM_1980s_diff <- data_merge$OM_1980-data_merge$OM_2010
data_merge$OM_2000s_diff <- data_merge$OM_2000-data_merge$OM_2010#需进行约束1 (四分位距 - IQR)
OM_1980s_diff_0.25 <- quantile(data_merge$OM_1980s_diff, 0.25)#OM_1980
OM_1980s_diff_0.75 <- quantile(data_merge$OM_1980s_diff, 0.75)
OM_1980s_diff_IQR <- OM_1980s_diff_0.75 - OM_1980s_diff_0.25
OM_1980s_diff_LL <-  OM_1980s_diff_0.25 - OM_1980s_diff_IQR*1.5
OM_1980s_diff_UL <-  OM_1980s_diff_0.75 + OM_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_1980s_diff[i] < OM_1980s_diff_LL){
    data_merge$OM_1980s_diff[i] <- OM_1980s_diff_LL
  } else if (data_merge$OM_1980s_diff[i] > OM_1980s_diff_UL){
    data_merge$OM_1980s_diff[i] <- OM_1980s_diff_UL
  }else {
    data_merge$OM_1980s_diff[i] <- data_merge$OM_1980s_diff[i]
  }
}
OM_2000s_diff_0.25 <- quantile(data_merge$OM_2000s_diff, 0.25)#OM_2000
OM_2000s_diff_0.75 <- quantile(data_merge$OM_2000s_diff, 0.75)
OM_2000s_diff_IQR <- OM_2000s_diff_0.75 - OM_2000s_diff_0.25
OM_2000s_diff_LL <-  OM_2000s_diff_0.25 - OM_2000s_diff_IQR*1.5
OM_2000s_diff_UL <-  OM_2000s_diff_0.75 + OM_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_2000s_diff[i] < OM_2000s_diff_LL){
    data_merge$OM_2000s_diff[i] <- OM_2000s_diff_LL
  } else if (data_merge$OM_2000s_diff[i] > OM_2000s_diff_UL){
    data_merge$OM_2000s_diff[i] <- OM_2000s_diff_UL
  } else {
    data_merge$OM_2000s_diff[i] <- data_merge$OM_2000s_diff[i]
  }
}
data_merge$OM_1980_value <- data_merge$OM+data_merge$OM_1980s_diff
data_merge$OM_2000_value <- data_merge$OM+data_merge$OM_2000s_diff
data_merge$OM_2010_value <- data_merge$OM#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_OM <- max(data_merge[,21:23])
min_OM <- min(data_merge[,21:23])
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_1980_value[i] < min_OM){
    data_merge$OM_1980_value[i] <- min_OM
  } else if (data_merge$OM_1980_value[i] > max_OM){
    data_merge$OM_1980_value[i] <- max_OM
  }else {
    data_merge$OM_1980_value[i] <- data_merge$OM_1980_value[i]
  }
}
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_2000_value[i] < min_OM){
    data_merge$OM_2000_value[i] <- min_OM
  } else if (data_merge$OM_2000_value[i] > max_OM){
    data_merge$OM_2000_value[i] <- max_OM
  }else {
    data_merge$OM_2000_value[i] <- data_merge$OM_2000_value[i]
  }
}
OM_year <- c('OM_1980','OM_2000','OM_2010')
OM_year_wb <- createWorkbook()
for (i in 1:length(OM_year)){
  addWorksheet(OM_year_wb,sheetName = OM_year[i])
}
for (i in 1:length(OM_year)){
  output_data <- data_merge[,c(4:15,(25+i),17:18)]
  colnames(output_data)[13] <- 'OM'
  writeData(OM_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(OM_year_wb, "China predict/soil acidification/data/predict/OM/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s OM变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 1)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###rice predict
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/OM/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/OM/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/OM/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/OM/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/OM/Rice province average.csv', row.names=FALSE)

###pH TN OM 三者同时变化
setwd("D:/master/project ing/soil plant/paper")
data_year <- c('data_1980','data_2000','data_2010')
data_year_wb <- createWorkbook()
for (i in 1:length(data_year)){
  addWorksheet(data_year_wb,sheetName = data_year[i])
}
for (i in 1:3){
  data_pH <- read.xlsx('China predict/soil acidification/data/predict/pH/data_1980_2000_2010.xlsx',i)
  data_TN <- read.xlsx('China predict/soil acidification/data/predict/TN/data_1980_2000_2010.xlsx',i)
  data_OM <- read.xlsx('China predict/soil acidification/data/predict/OM/data_1980_2000_2010.xlsx',i)
  data_pH$TN <- data_TN$TN
  data_pH$OM <- data_OM$OM
  writeData(data_year_wb, sheet = i, data_pH)
}
saveWorkbook(data_year_wb, "China predict/soil acidification/data/predict/3F co/data_1980_2000_2010.xlsx", overwrite = TRUE)
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 1)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/3F co/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/3F co/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/3F co/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/3F co/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/3F co/Rice province average.csv', row.names=FALSE)




###############################wheat wheat wheat wheat wheat wheat############################################################################
###pH
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_wheat_average.csv')
data_information <- read.csv('China predict/soil acidification/data/wheat coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country pH.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$pH_1980s_diff <- data_merge$pH_1980-data_merge$pH_2010
data_merge$pH_2000s_diff <- data_merge$pH_2000-data_merge$pH_2010#需进行约束1 (四分位距 - IQR)
pH_1980s_diff_0.25 <- quantile(data_merge$pH_1980s_diff, 0.25)#pH_1980
pH_1980s_diff_0.75 <- quantile(data_merge$pH_1980s_diff, 0.75)
pH_1980s_diff_IQR <- pH_1980s_diff_0.75 - pH_1980s_diff_0.25
pH_1980s_diff_LL <-  pH_1980s_diff_0.25 - pH_1980s_diff_IQR*1.5
pH_1980s_diff_UL <-  pH_1980s_diff_0.75 + pH_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_1980s_diff[i] < pH_1980s_diff_LL){
    data_merge$pH_1980s_diff[i] <- pH_1980s_diff_LL
  } else if (data_merge$pH_1980s_diff[i] > pH_1980s_diff_UL){
    data_merge$pH_1980s_diff[i] <- pH_1980s_diff_UL
  }else {
    data_merge$pH_1980s_diff[i] <- data_merge$pH_1980s_diff[i]
  }
}
pH_2000s_diff_0.25 <- quantile(data_merge$pH_2000s_diff, 0.25)#pH_2000
pH_2000s_diff_0.75 <- quantile(data_merge$pH_2000s_diff, 0.75)
pH_2000s_diff_IQR <- pH_2000s_diff_0.75 - pH_2000s_diff_0.25
pH_2000s_diff_LL <-  pH_2000s_diff_0.25 - pH_2000s_diff_IQR*1.5
pH_2000s_diff_UL <-  pH_2000s_diff_0.75 + pH_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_2000s_diff[i] < pH_2000s_diff_LL){
    data_merge$pH_2000s_diff[i] <- pH_2000s_diff_LL
  } else if (data_merge$pH_2000s_diff[i] > pH_2000s_diff_UL){
    data_merge$pH_2000s_diff[i] <- pH_2000s_diff_UL
  } else {
    data_merge$pH_2000s_diff[i] <- data_merge$pH_2000s_diff[i]
  }
}
data_merge$pH_1980_value <- data_merge$pH+data_merge$pH_1980s_diff
data_merge$pH_2000_value <- data_merge$pH+data_merge$pH_2000s_diff
data_merge$pH_2010_value <- data_merge$pH#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_pH <- max(data_merge[,21:23])
min_pH <- min(data_merge[,21:23])
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_1980_value[i] < min_pH){
    data_merge$pH_1980_value[i] <- min_pH
  } else if (data_merge$pH_1980_value[i] > max_pH){
    data_merge$pH_1980_value[i] <- max_pH
  }else {
    data_merge$pH_1980_value[i] <- data_merge$pH_1980_value[i]
  }
}
for (i in 1:length(data_merge$pH)){
  if (data_merge$pH_2000_value[i] < min_pH){
    data_merge$pH_2000_value[i] <- min_pH
  } else if (data_merge$pH_2000_value[i] > max_pH){
    data_merge$pH_2000_value[i] <- max_pH
  }else {
    data_merge$pH_2000_value[i] <- data_merge$pH_2000_value[i]
  }
}
pH_year <- c('pH_1980','pH_2000','pH_2010')
pH_year_wb <- createWorkbook()
for (i in 1:length(pH_year)){
  addWorksheet(pH_year_wb,sheetName = pH_year[i])
}
for (i in 1:length(pH_year)){
  output_data <- data_merge[,c(4:11,(25+i),13:18)]
  colnames(output_data)[9] <- 'pH'
  writeData(pH_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(pH_year_wb, "China predict/soil acidification/data/predict/pH/wheat/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s pH变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 2)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###wheat pH predict
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/pH/wheat/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/pH/wheat/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/pH/wheat/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/pH/wheat/result_data.csv', row.names=FALSE)

means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/pH/wheat/Wheat province average.csv', row.names=FALSE)


###TN
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_wheat_average.csv')
data_information <- read.csv('China predict/soil acidification/data/wheat coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country TN.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$TN_1980s_diff <- data_merge$TN_1980-data_merge$TN_2010
data_merge$TN_2000s_diff <- data_merge$TN_2000-data_merge$TN_2010#需进行约束1 (四分位距 - IQR)
TN_1980s_diff_0.25 <- quantile(data_merge$TN_1980s_diff, 0.25)#TN_1980
TN_1980s_diff_0.75 <- quantile(data_merge$TN_1980s_diff, 0.75)
TN_1980s_diff_IQR <- TN_1980s_diff_0.75 - TN_1980s_diff_0.25
TN_1980s_diff_LL <-  TN_1980s_diff_0.25 - TN_1980s_diff_IQR*1.5
TN_1980s_diff_UL <-  TN_1980s_diff_0.75 + TN_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_1980s_diff[i] < TN_1980s_diff_LL){
    data_merge$TN_1980s_diff[i] <- TN_1980s_diff_LL
  } else if (data_merge$TN_1980s_diff[i] > TN_1980s_diff_UL){
    data_merge$TN_1980s_diff[i] <- TN_1980s_diff_UL
  }else {
    data_merge$TN_1980s_diff[i] <- data_merge$TN_1980s_diff[i]
  }
}
TN_2000s_diff_0.25 <- quantile(data_merge$TN_2000s_diff, 0.25)#TN_2000
TN_2000s_diff_0.75 <- quantile(data_merge$TN_2000s_diff, 0.75)
TN_2000s_diff_IQR <- TN_2000s_diff_0.75 - TN_2000s_diff_0.25
TN_2000s_diff_LL <-  TN_2000s_diff_0.25 - TN_2000s_diff_IQR*1.5
TN_2000s_diff_UL <-  TN_2000s_diff_0.75 + TN_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_2000s_diff[i] < TN_2000s_diff_LL){
    data_merge$TN_2000s_diff[i] <- TN_2000s_diff_LL
  } else if (data_merge$TN_2000s_diff[i] > TN_2000s_diff_UL){
    data_merge$TN_2000s_diff[i] <- TN_2000s_diff_UL
  } else {
    data_merge$TN_2000s_diff[i] <- data_merge$TN_2000s_diff[i]
  }
}
data_merge$TN_1980_value <- data_merge$TN+data_merge$TN_1980s_diff
data_merge$TN_2000_value <- data_merge$TN+data_merge$TN_2000s_diff
data_merge$TN_2010_value <- data_merge$TN#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_TN <- max(data_merge[,21:23])
min_TN <- min(data_merge[,21:23])
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_1980_value[i] < min_TN){
    data_merge$TN_1980_value[i] <- min_TN
  } else if (data_merge$TN_1980_value[i] > max_TN){
    data_merge$TN_1980_value[i] <- max_TN
  }else {
    data_merge$TN_1980_value[i] <- data_merge$TN_1980_value[i]
  }
}
for (i in 1:length(data_merge$TN)){
  if (data_merge$TN_2000_value[i] < min_TN){
    data_merge$TN_2000_value[i] <- min_TN
  } else if (data_merge$TN_2000_value[i] > max_TN){
    data_merge$TN_2000_value[i] <- max_TN
  }else {
    data_merge$TN_2000_value[i] <- data_merge$TN_2000_value[i]
  }
}
TN_year <- c('TN_1980','TN_2000','TN_2010')
TN_year_wb <- createWorkbook()
for (i in 1:length(TN_year)){
  addWorksheet(TN_year_wb,sheetName = TN_year[i])
}
for (i in 1:length(TN_year)){
  output_data <- data_merge[,c(4:12,(25+i),14:18)]
  colnames(output_data)[10] <- 'TN'
  writeData(TN_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(TN_year_wb, "China predict/soil acidification/data/predict/TN/wheat/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s TN变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 2)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###rice predict
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/TN/wheat/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/TN/wheat/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/TN/wheat/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/TN/wheat/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/TN/wheat/Wheat province average.csv', row.names=FALSE)

###OM
#第三步 匹配到全国预测真实值的数据集中(data 与 data information匹配后再配对)
data <- read.csv('China predict/SD Data/data_wheat_average.csv')
data_information <- read.csv('China predict/soil acidification/data/wheat coor information.csv')
data_information <- data_information[,3:5]
colnames(data_information) <- c('country_revise','province_revise','city')
data_information <- cbind(data_information,data)
data_property <- read.csv('China predict/soil acidification/data/All country OM.csv')
data_merge <- plyr::join(data_information, data_property,by=c("country_revise","province_revise"))#有八个点位未匹配上
data_merge <- na.omit(data_merge)
#差值法对1980s&2000s计算(变化幅度),并写出3个数据集(顺序：1980 2000 2010)
data_merge$OM_1980s_diff <- data_merge$OM_1980-data_merge$OM_2010
data_merge$OM_2000s_diff <- data_merge$OM_2000-data_merge$OM_2010#需进行约束1 (四分位距 - IQR)
OM_1980s_diff_0.25 <- quantile(data_merge$OM_1980s_diff, 0.25)#OM_1980
OM_1980s_diff_0.75 <- quantile(data_merge$OM_1980s_diff, 0.75)
OM_1980s_diff_IQR <- OM_1980s_diff_0.75 - OM_1980s_diff_0.25
OM_1980s_diff_LL <-  OM_1980s_diff_0.25 - OM_1980s_diff_IQR*1.5
OM_1980s_diff_UL <-  OM_1980s_diff_0.75 + OM_1980s_diff_IQR*1.5
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_1980s_diff[i] < OM_1980s_diff_LL){
    data_merge$OM_1980s_diff[i] <- OM_1980s_diff_LL
  } else if (data_merge$OM_1980s_diff[i] > OM_1980s_diff_UL){
    data_merge$OM_1980s_diff[i] <- OM_1980s_diff_UL
  }else {
    data_merge$OM_1980s_diff[i] <- data_merge$OM_1980s_diff[i]
  }
}
OM_2000s_diff_0.25 <- quantile(data_merge$OM_2000s_diff, 0.25)#OM_2000
OM_2000s_diff_0.75 <- quantile(data_merge$OM_2000s_diff, 0.75)
OM_2000s_diff_IQR <- OM_2000s_diff_0.75 - OM_2000s_diff_0.25
OM_2000s_diff_LL <-  OM_2000s_diff_0.25 - OM_2000s_diff_IQR*1.5
OM_2000s_diff_UL <-  OM_2000s_diff_0.75 + OM_2000s_diff_IQR*1.5
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_2000s_diff[i] < OM_2000s_diff_LL){
    data_merge$OM_2000s_diff[i] <- OM_2000s_diff_LL
  } else if (data_merge$OM_2000s_diff[i] > OM_2000s_diff_UL){
    data_merge$OM_2000s_diff[i] <- OM_2000s_diff_UL
  } else {
    data_merge$OM_2000s_diff[i] <- data_merge$OM_2000s_diff[i]
  }
}
data_merge$OM_1980_value <- data_merge$OM+data_merge$OM_1980s_diff
data_merge$OM_2000_value <- data_merge$OM+data_merge$OM_2000s_diff
data_merge$OM_2010_value <- data_merge$OM#需进行约束2 (max min value:三个阶段的采样点的最小最大值)
max_OM <- max(data_merge[,21:23])
min_OM <- min(data_merge[,21:23])
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_1980_value[i] < min_OM){
    data_merge$OM_1980_value[i] <- min_OM
  } else if (data_merge$OM_1980_value[i] > max_OM){
    data_merge$OM_1980_value[i] <- max_OM
  }else {
    data_merge$OM_1980_value[i] <- data_merge$OM_1980_value[i]
  }
}
for (i in 1:length(data_merge$OM)){
  if (data_merge$OM_2000_value[i] < min_OM){
    data_merge$OM_2000_value[i] <- min_OM
  } else if (data_merge$OM_2000_value[i] > max_OM){
    data_merge$OM_2000_value[i] <- max_OM
  }else {
    data_merge$OM_2000_value[i] <- data_merge$OM_2000_value[i]
  }
}
OM_year <- c('OM_1980','OM_2000','OM_2010')
OM_year_wb <- createWorkbook()
for (i in 1:length(OM_year)){
  addWorksheet(OM_year_wb,sheetName = OM_year[i])
}
for (i in 1:length(OM_year)){
  output_data <- data_merge[,c(4:15,(25+i),17:18)]
  colnames(output_data)[13] <- 'OM'
  writeData(OM_year_wb, sheet = i, output_data)
  print(i)
}
saveWorkbook(OM_year_wb, "China predict/soil acidification/data/predict/OM/wheat/data_1980_2000_2010.xlsx", overwrite = TRUE)
###预测1980s和2000s OM变化下对Cd的影响
#注：预测1980s 2000s 2010s 一一对应的点
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 2)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
###rice predict
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/OM/wheat/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/OM/wheat/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/OM/wheat/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/OM/wheat/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/OM/wheat/Wheat province average.csv', row.names=FALSE)

###pH TN OM 三者同时变化
setwd("D:/master/project ing/soil plant/paper")
data_year <- c('data_1980','data_2000','data_2010')
data_year_wb <- createWorkbook()
for (i in 1:length(data_year)){
  addWorksheet(data_year_wb,sheetName = data_year[i])
}
for (i in 1:3){
  data_pH <- read.xlsx('China predict/soil acidification/data/predict/pH/wheat/data_1980_2000_2010.xlsx',i)
  data_TN <- read.xlsx('China predict/soil acidification/data/predict/TN/wheat/data_1980_2000_2010.xlsx',i)
  data_OM <- read.xlsx('China predict/soil acidification/data/predict/OM/wheat/data_1980_2000_2010.xlsx',i)
  data_pH$TN <- data_TN$TN
  data_pH$OM <- data_OM$OM
  writeData(data_year_wb, sheet = i, data_pH)
}
saveWorkbook(data_year_wb, "China predict/soil acidification/data/predict/3F co/wheat/data_1980_2000_2010.xlsx", overwrite = TRUE)
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 2)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
#predict
data_year <- c('data_1980','data_2000','data_2010')
data_year_wb <- createWorkbook()
for (i in 1:length(data_year)){
  addWorksheet(data_year_wb,sheetName = data_year[i])
}
for (n in 1:length(data_year)){
  predict_dataset <- read.xlsx('China predict/soil acidification/data/predict/3F co/wheat/data_1980_2000_2010.xlsx',n)
  coor_data <- predict_dataset[,1:2]
  province_data <- predict_dataset[,3]
  predict_data <- predict_dataset[,6:15]
  predict_result <- as.data.frame(predict(rf, predict_data))
  province_class_data <- cbind(coor_data,province_data,predict_result)
  colnames(province_class_data) <- c('X','Y','province','value')
  data_HLJ <- subset(province_class_data, province_class_data$province == 8)
  for (i in 1:length(data_HLJ[,1])){
    if (data_HLJ[i,4] > 0.08) {data_HLJ[i,4] <- data_HLJ[i,4]-0.04}
    else {data_HLJ[i,4] <- data_HLJ[i,4]}
  }
  data_JL <- subset(province_class_data, province_class_data$province == 7)
  for (i in 1:length(data_JL[,1])){
    if (data_JL[i,4] > 0.08) {data_JL[i,4] <- data_JL[i,4]-0.04}
    else {data_JL[i,4] <- data_JL[i,4]}
  }
  data_NM <- subset(province_class_data, province_class_data$province == 4)
  for (i in 1:length(data_NM[,1])){
    if (data_NM[i,4] > 0.08) {data_NM[i,4] <- data_NM[i,4]-0.04}
    else {data_NM[i,4] <- data_NM[i,4]}
  }
  data_XJ <- subset(province_class_data, province_class_data$province == 31)
  for (i in 1:length(data_XJ[,1])){
    if (data_XJ[i,4] > 0.08) {data_XJ[i,4] <- data_XJ[i,4]-0.04}
    else {data_XJ[i,4] <- data_XJ[i,4]}
  }
  data_FJ <- subset(province_class_data, province_class_data$province == 13)
  data_GD <- subset(province_class_data, province_class_data$province == 19)
  data_GX <- subset(province_class_data, province_class_data$province == 20)
  data_HN <- subset(province_class_data, province_class_data$province == 21)
  data_CQ <- subset(province_class_data, province_class_data$province == 22)
  data_GZ <- subset(province_class_data, province_class_data$province == 24)
  data_XZ <- subset(province_class_data, province_class_data$province == 26)
  data_NX <- subset(province_class_data, province_class_data$province == 30)
  data_NA <- rbind(data_FJ,data_GD,data_GX,data_HN,data_CQ,data_GZ,data_XZ,data_NX)
  data_NA[,4] <- 0
  
  province_class_data <- subset(province_class_data, province_class_data$province != 4)
  province_class_data <- subset(province_class_data, province_class_data$province != 7)
  province_class_data <- subset(province_class_data, province_class_data$province != 8)
  province_class_data <- subset(province_class_data, province_class_data$province != 31)
  province_class_data <- subset(province_class_data, province_class_data$province != 13)
  province_class_data <- subset(province_class_data, province_class_data$province != 19)
  province_class_data <- subset(province_class_data, province_class_data$province != 20)
  province_class_data <- subset(province_class_data, province_class_data$province != 21)
  province_class_data <- subset(province_class_data, province_class_data$province != 22)
  province_class_data <- subset(province_class_data, province_class_data$province != 24)
  province_class_data <- subset(province_class_data, province_class_data$province != 26)
  province_class_data <- subset(province_class_data, province_class_data$province != 30)
  province_class_data <- rbind(province_class_data, data_HLJ, data_JL, data_NM,data_XJ,data_XZ,data_NA)
  writeData(data_year_wb, sheet = n, province_class_data)
  print(n)
}
saveWorkbook(data_year_wb, "China predict/soil acidification/data/predict/3F co/wheat/map_data.xlsx", overwrite = TRUE)
#result data
result_data1 <- read.xlsx("China predict/soil acidification/data/predict/3F co/wheat/map_data.xlsx",1)
result_data2 <- read.xlsx("China predict/soil acidification/data/predict/3F co/wheat/map_data.xlsx",2)
result_data3 <- read.xlsx("China predict/soil acidification/data/predict/3F co/wheat/map_data.xlsx",3)
result_data <- cbind(result_data1, result_data2[,4], result_data3[,4])
colnames(result_data) <- c('X','Y','province','value_1980','value_2000','value_2010')
write.csv(result_data,'China predict/soil acidification/data/predict/3F co/wheat/result_data.csv', row.names=FALSE)
#平均值
means <- data.frame()
for (i in 0:31){
  data_province <- subset(result_data, result_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/soil acidification/data/predict/3F co/wheat/Wheat province average.csv', row.names=FALSE)


###计算健康危险指数各省变化情况
setwd('D:/master/project ing/soil plant/paper')
EF = 350;ED_Adult=45;ED_Children=9
AT_Adult=45*365;AT_Children=9*365;RfD=1
#Rice
parameter <- read.csv('China predict/THQ计算参数/Rice parameter.csv')
data_year <- c('data_1980','data_2000','data_2010','data_1980_3F','data_2000_3F','data_2010_3F')
data_year_wb <- createWorkbook()
for (i in 1:length(data_year)){
  addWorksheet(data_year_wb,sheetName = data_year[i])
}
for (n in 1:length(data_year)){
  parameter_frame <- read.xlsx('China predict/soil acidification/data/predict/pH/Rice province average.xlsx',n)
  NE_frame <- subset(parameter_frame, parameter_frame$region == 'NE')
  NE_frame <- subset(NE_frame, NE_frame$net.output > 0)
  Cd_NE <- sum(NE_frame$value*NE_frame$net.output)/sum(NE_frame$net.output)
  #华东地区ES输出稻米的Cd含量平均值
  ES_frame <- subset(parameter_frame, parameter_frame$region == 'ES')
  ES_frame <- subset(ES_frame, ES_frame$net.output > 0)
  Cd_ES <- sum(ES_frame$value*ES_frame$net.output)/sum(ES_frame$net.output)
  #中南地区MS输出稻米的Cd含量平均值
  MS_frame <- subset(parameter_frame, parameter_frame$region == 'MS')
  MS_frame <- subset(MS_frame, MS_frame$net.output > 0)
  Cd_MS <- sum(MS_frame$value*MS_frame$net.output)/sum(MS_frame$net.output)
  #西南地区SW输出稻米的Cd含量平均值
  SW_frame <- subset(parameter_frame, parameter_frame$region == 'SW')
  SW_frame <- subset(SW_frame, SW_frame$net.output > 0)
  Cd_SW <- sum(SW_frame$value*SW_frame$net.output)/sum(SW_frame$net.output)
  #西北地区NW输出稻米的Cd含量平均值
  #(不输出)
  #西南、中南、东北综合Cd含量平均值
  Cd_mix <- (Cd_NE*sum(NE_frame$net.output) + 
               Cd_MS*sum(MS_frame$net.output) +
               Cd_SW*sum(SW_frame$net.output))/(sum(NE_frame$net.output)+sum(MS_frame$net.output)+sum(SW_frame$net.output))
  Cd_intake <- data.frame()
  for (i in 1:length(parameter_frame[,1])){
    if (parameter_frame$net.output[i] > 0) {
      Cd_intake_one <- parameter_frame$value[i]
    }else {
      if (parameter_frame$region[i] == 'NC'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NE*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'ES'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_ES*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'MS'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_MS*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'SW'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_SW*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else{
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_mix*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }
    }
    Cd_intake <- rbind(Cd_intake,Cd_intake_one)
  }
  Cd_intake_province <- as.data.frame(c('Beijing','Tianjin','Hebei','Shanxi','Neimenggu','Liaoning','Jilin','Heilongjiang',
                                        'Shanghai','Jiangsu','Zhejiang','Anhui','Fujian','Jiangxi','Shandong','Henan',
                                        'Hubei','Hunan','Guangdong','Guangxi','Hainan','Chongqing','Sichuan','Guizhou',
                                        'Yunnan','Xizang','Shannxi','Gansu','Qinghai','Ningxia','Xinjiang'))
  Cd_intake <- cbind(Cd_intake_province,Cd_intake)
  colnames(Cd_intake) <- c('province','intake_C')
  
  #Adult
  data_Adult <- as.data.frame((Cd_intake$intake_C*parameter$Adult.IR*EF*ED_Adult)/(parameter$Adult.WB*AT_Adult*RfD))
  colnames(data_Adult) <- 'HQ'
  data_Adult <- cbind(parameter$province,data_Adult)
  colnames(data_Adult) <- c('Province','HQ_Adult')
  #Children
  data_Children <- as.data.frame((Cd_intake$intake_C*parameter$Children.IR*EF*ED_Children)/(parameter$Children.WB*AT_Children*RfD))
  colnames(data_Children) <- 'HQ'
  data_Children <- cbind(parameter$province,data_Children)
  colnames(data_Children) <- c('Province','HQ_Children')
  
  data_Adult_Children <- cbind(data_Adult,data_Children)
  data_Adult_Children <- data_Adult_Children[,-3]
  
  writeData(data_year_wb, sheet = n, data_Adult_Children)
}
saveWorkbook(data_year_wb, "China predict/soil acidification/data/predict/pH/Rice HQ.xlsx", overwrite = TRUE)
0.12515605
#Wheat
parameter <- read.csv('China predict/THQ计算参数/Wheat parameter.csv')
data_year <- c('data_1980','data_2000','data_2010','data_1980_3F','data_2000_3F','data_2010_3F')
data_year_wb <- createWorkbook()
for (i in 1:length(data_year)){
  addWorksheet(data_year_wb,sheetName = data_year[i])
}
for (n in 1:length(data_year)){
  parameter_frame <- read.xlsx('China predict/soil acidification/data/predict/pH/Wheat/Wheat province average.xlsx',n)
  NC_frame <- subset(parameter_frame, parameter_frame$region == 'NC')
  NC_frame <- subset(NC_frame, NC_frame$net.output > 0)
  Cd_NC <- sum(NC_frame$value*NC_frame$yield)/sum(NC_frame$yield)
  #东北地区NE输出小麦的Cd含量平均值
  #(不输出)
  #NE_frame <- subset(parameter_frame, parameter_frame$region == 'NE')
  #NE_frame <- subset(NE_frame, NE_frame$net.output > 0)
  #Cd_NE <- sum(NE_frame$value*NE_frame$net.output)/sum(NE_frame$net.output)
  #华东地区ES输出小麦的Cd含量平均值
  ES_frame <- subset(parameter_frame, parameter_frame$region == 'ES')
  ES_frame <- subset(ES_frame, ES_frame$net.output > 0)
  Cd_ES <- sum(ES_frame$value*ES_frame$net.output)/sum(ES_frame$net.output)
  #中南地区MS输出小麦的Cd含量平均值
  MS_frame <- subset(parameter_frame, parameter_frame$region == 'MS')
  MS_frame <- subset(MS_frame, MS_frame$net.output > 0)
  Cd_MS <- sum(MS_frame$value*MS_frame$net.output)/sum(MS_frame$net.output)
  #西南地区SW输出小麦的Cd含量平均值
  #(不输出)
  #SW_frame <- subset(parameter_frame, parameter_frame$region == 'SW')
  #SW_frame <- subset(SW_frame, SW_frame$net.output > 0)
  #Cd_SW <- sum(SW_frame$value*SW_frame$net.output)/sum(SW_frame$net.output)
  #西北地区NW输出小麦的Cd含量平均值
  NW_frame <- subset(parameter_frame, parameter_frame$region == 'NW')
  NW_frame <- subset(NW_frame, NW_frame$net.output > 0)
  Cd_NW <- sum(NW_frame$value*NW_frame$net.output)/sum(NW_frame$net.output)
  #西北、中南综合Cd含量平均值
  Cd_mix <- (Cd_NW*sum(NW_frame$net.output) + 
               Cd_MS*sum(MS_frame$net.output))/(sum(NW_frame$net.output)+sum(MS_frame$net.output))
  #计算需供给省份的平均值(产量和净输入为加权系数)
  Cd_intake <- data.frame()
  for (i in 1:length(parameter_frame[,1])){
    if (parameter_frame$net.output[i] > 0) {
      Cd_intake_one <- parameter_frame$value[i]
    }else {
      if (parameter_frame$region[i] == 'NC'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NC*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'NE'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NC*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'ES'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_ES*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'MS'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_MS*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else if (parameter_frame$region[i] == 'SW'){
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_mix*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }else{
        Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NW*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
      }
    }
    Cd_intake <- rbind(Cd_intake,Cd_intake_one)
  }
  Cd_intake_province <- as.data.frame(c('Beijing','Tianjin','Hebei','Shanxi','Neimenggu','Liaoning','Jilin','Heilongjiang',
                                        'Shanghai','Jiangsu','Zhejiang','Anhui','Fujian','Jiangxi','Shandong','Henan',
                                        'Hubei','Hunan','Guangdong','Guangxi','Hainan','Chongqing','Sichuan','Guizhou',
                                        'Yunnan','Xizang','Shannxi','Gansu','Qinghai','Ningxia','Xinjiang'))
  Cd_intake <- cbind(Cd_intake_province,Cd_intake)
  colnames(Cd_intake) <- c('province','intake_C')
  
  #Adult
  data_Adult <- as.data.frame((Cd_intake$intake_C*parameter$Adult.IR*EF*ED_Adult)/(parameter$Adult.WB*AT_Adult*RfD))
  colnames(data_Adult) <- 'HQ'
  data_Adult <- cbind(parameter$province,data_Adult)
  colnames(data_Adult) <- c('Province','HQ_Adult')

  #Children
  data_Children <- as.data.frame((Cd_intake$intake_C*parameter$Children.IR*EF*ED_Children)/(parameter$Children.WB*AT_Children*RfD))
  colnames(data_Children) <- 'HQ'
  data_Children <- cbind(parameter$province,data_Children)
  colnames(data_Children) <- c('Province','HQ_Children')
  
  data_Adult_Children <- cbind(data_Adult,data_Children)
  data_Adult_Children <- data_Adult_Children[,-3]
  
  writeData(data_year_wb, sheet = n, data_Adult_Children)
}
saveWorkbook(data_year_wb, "China predict/soil acidification/data/predict/pH/Wheat/Wheat HQ.xlsx", overwrite = TRUE)
#条形图见plot data & code
















































