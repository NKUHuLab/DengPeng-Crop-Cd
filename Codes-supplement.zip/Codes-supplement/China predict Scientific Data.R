###rice和wheat的分布数据来自Scientific Data <Maps of cropping patterns in China during 2015–2021>
###使用该数据集，不分种类预测
library(raster)
library(rasterVis)
library(RColorBrewer)
library(ncdf4)
library(rgdal)
library(caret)
library(randomForest)
library(xlsx)
library(readxl)
library(openxlsx)
library(writexl)
library(factoextra)
library(FactoMineR)
library(dplyr)
library(maptools)  
library(rgdal)
library(tidyverse)

setwd("D:/master/project ing/soil plant/paper")
################################################################################
###dataset  rice dataset(China crop distribution 2020)
crop <- raster('China predict/crop/China crop distribution 2020/China 2020.tif')
plot(crop)
#提取rice分布点
crop_frame <- as.data.frame(crop, xy=T)
coor <- na.omit(as.data.frame(crop, xy=T))
colnames(coor)[3] <- 'type'
coor_rice <- subset(coor, type == 15 | type == 245 | type == 255 | type == 256)
coor_rice <- coor_rice[,1:2]
###赋值省份信息(为后续Cd赋值提供依据)
province <- raster('China predict/True value/province classification.tif')
province_frame <- as.data.frame(raster::extract(province, coor_rice))
colnames(province_frame) <- c('province')

###Climate MAT MAP
setwd("D:/master/project ing/soil plant/paper/China predict/climate")
MAT <- raster('2020 T/MAT 2020.tif')
MAT_value <- as.data.frame(raster::extract(MAT, coor_rice))
MAT_value <- MAT_value*0.1
MAR <- raster('2020 R/MAP 2020.tif')
MAR_value <- as.data.frame(raster::extract(MAR, coor_rice))
MAR_value <- MAR_value*0.1
Climate <- cbind(MAT_value,MAR_value)
colnames(Climate) <- c('MAT','MAP')
###Soil pH TN TP OM pH CEC
setwd("D:/master/project ing/soil plant/paper/China predict/soil")
pH <- raster('PH/PH.tif')
pH_value <- as.data.frame(raster::extract(pH, coor_rice))
TN <- raster('TN/TN.tif')
TN_value <- as.data.frame(raster::extract(TN, coor_rice))
TN_value <- TN_value*10
#AN <- raster('AN/AN.tif')
#AN_value <- as.data.frame(raster::extract(AN, coor_rice))
#AN_value <- AN_value*0.001
TP <- raster('TP/TP.tif')
TP_value <- as.data.frame(raster::extract(TP, coor_rice))
TP_value <- TP_value*10000
#AP <- raster('AP/AP.tif')
#AP_value <- as.data.frame(raster::extract(AP, coor_rice))
AK <- raster('AK/AK.tif')
AK_value <- as.data.frame(raster::extract(AK, coor_rice))
AK_value <- AK_value*0.001
OM <- raster('SOM/SOM.tif')
OM_value <- as.data.frame(raster::extract(OM, coor_rice))
OM_value <- OM_value*10
CEC <- raster('CEC/CEC.tif')
CEC_value <- as.data.frame(raster::extract(CEC, coor_rice))
Soil <- cbind(pH_value,TN_value,TP_value,AK_value,OM_value,CEC_value)
colnames(Soil) <- c('pH','TN','TP','AK','OM','CEC')

###人为设置Site Farmland Sitein & Cd State Type
#Site:0
#Farmland:1
#Sitein:0
#Cd:
#State:T 不需要
#Type:IY(众数) 不需要
###Site
Site <- c(rep(0,nrow(coor_rice)))
Farmland <- c(rep(1,nrow(coor_rice)))
Sitein <- c(rep(0,nrow(coor_rice)))
Site_frame <- data.frame(Site, Farmland, Sitein)
###Cd
setwd("D:/master/project ing/soil plant/paper/China predict/Cd concentration")
#Cd <- c(rep(0,nrow(coor_rice)))
#Cd_frame <- data.frame(Cd)
Cd <- raster('Cd_Krig.tif')
Cd_value <- as.data.frame(raster::extract(Cd, coor_rice))
Cd_frame <- data.frame(Cd_value)
colnames(Cd_frame) <- c('Cd')

###Rice data 汇总
data_rice <- cbind(coor_rice, province_frame, Climate, Site_frame, Soil, Cd_frame)
data_rice <- na.omit(data_rice)
#除去中朝共有/香港/澳门/台湾  数据不足
data_rice <- subset(data_rice, data_rice$province != 5)
data_rice <- subset(data_rice, data_rice$province != 32)
data_rice <- subset(data_rice, data_rice$province != 33)
data_rice <- subset(data_rice, data_rice$province != 34)
setwd("D:/master/project ing/soil plant/paper/China predict")
write.csv(data_rice,'SD Data/data_rice_average.csv', row.names=FALSE)

###rice predict
setwd('D:/master/project ing/soil plant/paper')
#准备预测数据
data <- read.csv('China predict/SD Data/data_rice_average.csv')
coor_data <- data[,1:2]
province_data <- data[,3]
predict_dataset <- data[,6:15]
#predict_dataset <- predict_dataset[,-c(6,8)]

#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 1)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
               ntree=500,mtry=7,
               proximity = F,
               importance = F)
predict_value <- as.data.frame(predict(rf, predict_dataset))
map_data <- cbind(coor_data, predict_value)
colnames(map_data) <- c('X','Y','value')
province_class_data <- cbind(coor_data,province_data, predict_value)
colnames(province_class_data) <- c('X','Y','province','value')

#各省平均值
setwd('D:/master/project ing/soil plant/paper')
data <- read.csv('China predict/SD Data/data_rice_average.csv')
means <- data.frame()
for (i in 0:31){
  data_province <- subset(data_rice, data_rice$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/SD Data/Rice province feature average value.csv', row.names=FALSE)

setwd('D:/master/project ing/soil plant/paper')
means <- data.frame()
for (i in 0:31){
  data_province <- subset(province_class_data, province_class_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/SD Data/Rice province average.csv', row.names=FALSE)

###需供给的省份 所涉及的参数见“参数.xlsx”
#北京 天津 河北 山西 内蒙 上海 浙江 山东 河南 西藏 陕西 甘肃 青海 新疆
#NE，中国东北地区；NC，华北地区；ES，华东地区；MS，中南地区；SW，西南地区；NW，西北地区
#北京/天津/河北/山西/内蒙：由东北地区输入
#上海/浙江/山东:由华东地区输入
#河南：由中南地区输入
#西藏：由西南地区输入
#陕西/甘肃/青海/新疆:由西南、中南、东北地区输入
#东北地区输出稻米的Cd含量平均值
setwd('D:/master/project ing/soil plant/paper')
parameter_frame <- read.csv('China predict/SD Data/Rice province average.csv')
#single region
#华北地区NC输出稻米的Cd含量平均值
#(不输出)
#NC_frame <- subset(parameter_frame, parameter_frame$region == 'NC')
#Cd_NC <- sum(NC_frame$value*NC_frame$yield)/sum(NC_frame$yield)
#东北地区NE输出稻米的Cd含量平均值
NE_frame <- subset(parameter_frame, parameter_frame$region == 'NE')
NE_frame <- subset(NE_frame, NE_frame$net.output > 0)
Cd_NE <- sum(NE_frame$value*NE_frame$net.output)/sum(NE_frame$net.output)
#华东地区ES输出稻米的Cd含量平均值
ES_frame <- subset(parameter_frame, parameter_frame$region == 'ES')
ES_frame <- subset(ES_frame, ES_frame$net.output > 0)
Cd_ES <- sum(ES_frame$value*ES_frame$net.output)/sum(ES_frame$net.output)
#中南地区MS输出稻米的Cd含量平均值
MS_frame <- subset(parameter_frame, parameter_frame$region == 'MS')
MS_frame <- subset(MS_frame, MS_frame$net.output > 0)
Cd_MS <- sum(MS_frame$value*MS_frame$net.output)/sum(MS_frame$net.output)
#西南地区SW输出稻米的Cd含量平均值
SW_frame <- subset(parameter_frame, parameter_frame$region == 'SW')
SW_frame <- subset(SW_frame, SW_frame$net.output > 0)
Cd_SW <- sum(SW_frame$value*SW_frame$net.output)/sum(SW_frame$net.output)
#西北地区NW输出稻米的Cd含量平均值
#(不输出)
#西南、中南、东北综合Cd含量平均值
Cd_mix <- (Cd_NE*sum(NE_frame$net.output) + 
           Cd_MS*sum(MS_frame$net.output) +
           Cd_SW*sum(SW_frame$net.output))/(sum(NE_frame$net.output)+sum(MS_frame$net.output)+sum(SW_frame$net.output))

#计算需供给省份的平均值(产量和净输入为加权系数)
Cd_intake <- data.frame()
for (i in 1:length(parameter_frame[,1])){
  if (parameter_frame$net.output[i] > 0) {
    Cd_intake_one <- parameter_frame$value[i]
  }else {
    if (parameter_frame$region[i] == 'NC'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NE*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'ES'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_ES*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'MS'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_MS*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'SW'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_SW*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else{
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_mix*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }
  }
  Cd_intake <- rbind(Cd_intake,Cd_intake_one)
}
Cd_intake_province <- as.data.frame(c('Beijing','Tianjin','Hebei','Shanxi','Neimenggu','Liaoning','Jilin','Heilongjiang',
                                      'Shanghai','Jiangsu','Zhejiang','Anhui','Fujian','Jiangxi','Shandong','Henan',
                                      'Hubei','Hunan','Guangdong','Guangxi','Hainan','Chongqing','Sichuan','Guizhou',
                                      'Yunnan','Xizang','Shannxi','Gansu','Qinghai','Ningxia','Xinjiang'))
Cd_intake <- cbind(Cd_intake_province,Cd_intake)
colnames(Cd_intake) <- c('province','intake_C')
write.csv(Cd_intake,'China predict/THQ计算参数/Rice intake Cd concentration.csv', row.names=FALSE)

###健康危险指数(或致癌风险CR？)
#HQ = (Ci*IR*EF*ED)/(BW*AT*RfD)
#Ci:稻米中的Cd含量(mg/Kg)
#IR：稻米摄入量(儿童/成年人 kg/d)
#EF:暴露频率(d/a)
#ED：暴露持续时间(儿童/成年人 9/45 a)
#BW:体重(儿童/成年人 kg)
#AT:平均时间(致癌：ED*365 d/a)
#RfD:口服剂量(mg/(kg d),)
EF = 350;ED_Adult=45;ED_Children=9
AT_Adult=45*365;AT_Children=9*365;RfD=1
setwd('D:/master/project ing/soil plant/paper')
parameter <- read.csv('China predict/THQ计算参数/Rice parameter.csv')
#Adult
data_Adult <- as.data.frame((parameter$Cd*parameter$Adult.IR*EF*ED_Adult)/(parameter$Adult.WB*AT_Adult*RfD))
colnames(data_Adult) <- 'HQ'
data_Adult <- cbind(parameter$province,data_Adult)
colnames(data_Adult) <- c('Province','HQ')
write.csv(data_Adult,'China predict/THQ计算参数/Rice Adult HQ.csv', row.names=FALSE)
#Children
data_Children <- as.data.frame((parameter$Cd*parameter$Children.IR*EF*ED_Children)/(parameter$Children.WB*AT_Children*RfD))
colnames(data_Children) <- 'HQ'
data_Children <- cbind(parameter$province,data_Children)
colnames(data_Children) <- c('Province','HQ')
write.csv(data_Children,'China predict/THQ计算参数/Rice Children HQ.csv', row.names=FALSE)


########wheat#######
################################################################################
setwd("D:/master/project ing/soil plant/paper")
###wheat dataset1
crop <- raster('China predict/crop/China crop distribution 2020/China 2020.tif')
plot(crop)
crop_frame <- as.data.frame(crop, xy=T)
coor <- na.omit(as.data.frame(crop, xy=T))
colnames(coor)[3] <- 'type'
coor_wheat <- subset(coor,  type == 16 | type == 246 | type == 256)
coor_wheat <- coor_wheat[,1:2]
###赋值省份信息(为后续Cd赋值提供依据)
province <- raster('China predict/True value/province classification.tif')
province_frame <- as.data.frame(raster::extract(province, coor_wheat))
colnames(province_frame) <- c('province')

###Climate MAT MAP
setwd("D:/master/project ing/soil plant/paper/China predict/climate")
###MAT DATA
MAT <- raster('2020 T/MAT 2020.tif')
MAT_value <- as.data.frame(raster::extract(MAT, coor_wheat))
MAT_value <- MAT_value*0.1
MAR <- raster('2020 R/MAP 2020.tif')
MAR_value <- as.data.frame(raster::extract(MAR, coor_wheat))
MAR_value <- MAR_value*0.1
Climate <- cbind(MAT_value,MAR_value)
colnames(Climate) <- c('MAT','MAP')

###Soil pH TN TP OM pH CEC
setwd("D:/master/project ing/soil plant/paper/China predict/soil")
pH <- raster('PH/PH.tif')
pH_value <- as.data.frame(raster::extract(pH, coor_wheat))
TN <- raster('TN/TN.tif')
TN_value <- as.data.frame(raster::extract(TN, coor_wheat))
TN_value <- TN_value*10
#AN <- raster('AN/AN.tif')
#AN_value <- as.data.frame(raster::extract(AN, coor_wheat))
#AN_value <- AN_value*0.001
TP <- raster('TP/TP.tif')
TP_value <- as.data.frame(raster::extract(TP, coor_wheat))
TP_value <- TP_value*10000
#AP <- raster('AP/AP.tif')
#AP_value <- as.data.frame(raster::extract(AP, coor_wheat))
AK <- raster('AK/AK.tif')
AK_value <- as.data.frame(raster::extract(AK, coor_wheat))
AK_value <- AK_value*0.001
OM <- raster('SOM/SOM.tif')
OM_value <- as.data.frame(raster::extract(OM, coor_wheat))
OM_value <- OM_value*10
CEC <- raster('CEC/CEC.tif')
CEC_value <- as.data.frame(raster::extract(CEC, coor_wheat))
Soil <- cbind(pH_value,TN_value,TP_value,AK_value,OM_value,CEC_value)
colnames(Soil) <- c('pH','TN','TP','AK','OM','CEC')

###人为设置Site Farmland Sitein & Cd State Type
#Site:0
#Farmland:1
#Sitein:0
#Cd:
#State:T 不需要
#Type:IY(众数) 不需要
###Site
Site <- c(rep(0,nrow(coor_wheat)))
Farmland <- c(rep(1,nrow(coor_wheat)))
Sitein <- c(rep(0,nrow(coor_wheat)))
Site_frame <- data.frame(Site, Farmland, Sitein)
###Cd
setwd("D:/master/project ing/soil plant/paper/China predict/Cd concentration")
#Cd <- c(rep(0,nrow(coor_wheat)))
#Cd_frame <- data.frame(Cd)
Cd <- raster('Cd_Krig.tif')
Cd_value <- as.data.frame(raster::extract(Cd, coor_wheat))
Cd_frame <- data.frame(Cd_value)
colnames(Cd_frame) <- c('Cd')

###Wheat data 汇总
data_wheat <- cbind(coor_wheat, province_frame, Climate, Site_frame, Soil, Cd_frame)
data_wheat <- na.omit(data_wheat)
#除去中朝共有/香港/澳门/台湾  数据不足
data_wheat <- subset(data_wheat, data_wheat$province != 5) 
data_wheat <- subset(data_wheat, data_wheat$province != 32) 
data_wheat <- subset(data_wheat, data_wheat$province != 33) 
data_wheat <- subset(data_wheat, data_wheat$province != 34) 
setwd("D:/master/project ing/soil plant/paper/China predict")
write.csv(data_wheat,'SD Data/data_wheat_average.csv', row.names=FALSE)

###wheat predict
setwd('D:/master/project ing/soil plant/paper')
#准备预测数据
data <- read.csv('China predict/SD Data/data_wheat_average.csv')
coor_data <- data[,1:2]
province_data <- data[,3]
predict_dataset <- data[,6:15]
#建立模型
dataset <- read.xlsx('grain model build/data_Cd.xlsx', 2)
dataset <- dataset[,3:14]
dataset <- dataset[,-c(11)]
colnames(dataset)[length(dataset[1,])]<-'index'
dataset$index<-as.numeric(dataset$index)
rf<-randomForest(index~. , data = dataset, 
                 ntree=500,mtry=7,
                 proximity = F,
                 importance = F)
predict_value <- as.data.frame(predict(rf, predict_dataset))
map_data <- cbind(coor_data, predict_value)
colnames(map_data) <- c('X','Y','value')
province_class_data <- cbind(coor_data,province_data, predict_value)
colnames(province_class_data) <- c('X','Y','province','value')

data_FJ <- subset(province_class_data, province_class_data$province == 13)
data_GD <- subset(province_class_data, province_class_data$province == 19)
data_GX <- subset(province_class_data, province_class_data$province == 20)
data_HN <- subset(province_class_data, province_class_data$province == 21)
data_CQ <- subset(province_class_data, province_class_data$province == 22)
data_GZ <- subset(province_class_data, province_class_data$province == 24)
data_XZ <- subset(province_class_data, province_class_data$province == 26)
data_NX <- subset(province_class_data, province_class_data$province == 30)
data_NA <- rbind(data_FJ,data_GD,data_GX,data_HN,data_CQ,data_GZ,data_XZ,data_NX)
data_NA[,4] <- 0

province_class_data <- subset(province_class_data, province_class_data$province != 4)
province_class_data <- subset(province_class_data, province_class_data$province != 7)
province_class_data <- subset(province_class_data, province_class_data$province != 8)
province_class_data <- subset(province_class_data, province_class_data$province != 31)
province_class_data <- subset(province_class_data, province_class_data$province != 13)
province_class_data <- subset(province_class_data, province_class_data$province != 19)
province_class_data <- subset(province_class_data, province_class_data$province != 20)
province_class_data <- subset(province_class_data, province_class_data$province != 21)
province_class_data <- subset(province_class_data, province_class_data$province != 22)
province_class_data <- subset(province_class_data, province_class_data$province != 24)
province_class_data <- subset(province_class_data, province_class_data$province != 26)
province_class_data <- subset(province_class_data, province_class_data$province != 30)

province_class_data <- rbind(province_class_data, data_HLJ, data_JL, data_NM,data_XJ,data_XZ,data_NA)
map_data <- province_class_data[,-3]
map_data <- subset(map_data,map_data$value > 0)
write.csv(province_class_data,'China predict/SD Data/wheat_province_class_data.csv', row.names=FALSE)
write.csv(map_data,'China predict/SD Data/wheat_map_data_average.csv', row.names=FALSE)

#各省平均值feature和label
setwd('D:/master/project ing/soil plant/paper')
data <- read.csv('China predict/SD Data/data_wheat_average.csv')
means <- data.frame()
for (i in 0:31){
  data_province <- subset(data, data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/SD Data/Wheat province feature average value.csv', row.names=FALSE)

setwd('D:/master/project ing/soil plant/paper')
means <- data.frame()
for (i in 0:31){
  data_province <- subset(province_class_data, province_class_data$province == i) 
  means_one <- t(as.data.frame(colMeans(data_province)))
  means <- rbind(means, means_one)
}
rownames(means) <- c(0:31)
write.csv(means,'China predict/SD Data/Wheat province average.csv', row.names=FALSE)

###需供给的省份 所涉及的参数见“参数.xlsx”
#NE，中国东北地区；NC，华北地区；ES，华东地区；MS，中南地区；SW，西南地区；NW，西北地区
#点少设置为0的省份：
#北京 辽宁 吉林 黑龙江 上海 浙江 福建 江西 湖南 广东 广西 海南 重庆 四川  贵州 云南 西藏 宁夏
#北京：由华北地区输入
#辽宁/吉林/黑龙江:由华北地区输入
#上海/浙江/福建/江西：由华东地区输入
#广东/广西/海南：由华中和华东地区输入
#重庆/四川/贵州/云南/西藏:由中南、西北地区输入
#宁夏：由西北地区输入
setwd('D:/master/project ing/soil plant/paper')
parameter_frame <- read.csv('China predict/SD Data/Wheat province average.csv')
#single region
#华北地区NC输出小麦的Cd含量平均值
NC_frame <- subset(parameter_frame, parameter_frame$region == 'NC')
NC_frame <- subset(NC_frame, NC_frame$net.output > 0)
Cd_NC <- sum(NC_frame$value*NC_frame$yield)/sum(NC_frame$yield)
#东北地区NE输出小麦的Cd含量平均值
#(不输出)
#NE_frame <- subset(parameter_frame, parameter_frame$region == 'NE')
#NE_frame <- subset(NE_frame, NE_frame$net.output > 0)
#Cd_NE <- sum(NE_frame$value*NE_frame$net.output)/sum(NE_frame$net.output)
#华东地区ES输出小麦的Cd含量平均值
ES_frame <- subset(parameter_frame, parameter_frame$region == 'ES')
ES_frame <- subset(ES_frame, ES_frame$net.output > 0)
Cd_ES <- sum(ES_frame$value*ES_frame$net.output)/sum(ES_frame$net.output)
#中南地区MS输出小麦的Cd含量平均值
MS_frame <- subset(parameter_frame, parameter_frame$region == 'MS')
MS_frame <- subset(MS_frame, MS_frame$net.output > 0)
Cd_MS <- sum(MS_frame$value*MS_frame$net.output)/sum(MS_frame$net.output)
#西南地区SW输出小麦的Cd含量平均值
#(不输出)
#SW_frame <- subset(parameter_frame, parameter_frame$region == 'SW')
#SW_frame <- subset(SW_frame, SW_frame$net.output > 0)
#Cd_SW <- sum(SW_frame$value*SW_frame$net.output)/sum(SW_frame$net.output)
#西北地区NW输出小麦的Cd含量平均值
NW_frame <- subset(parameter_frame, parameter_frame$region == 'NW')
NW_frame <- subset(NW_frame, NW_frame$net.output > 0)
Cd_NW <- sum(NW_frame$value*NW_frame$net.output)/sum(NW_frame$net.output)
#西北、中南综合Cd含量平均值
Cd_mix <- (Cd_NW*sum(NW_frame$net.output) + 
             Cd_MS*sum(MS_frame$net.output))/(sum(NW_frame$net.output)+sum(MS_frame$net.output))
#计算需供给省份的平均值(产量和净输入为加权系数)
Cd_intake <- data.frame()
for (i in 1:length(parameter_frame[,1])){
  if (parameter_frame$net.output[i] > 0) {
    Cd_intake_one <- parameter_frame$value[i]
  }else {
    if (parameter_frame$region[i] == 'NC'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NC*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'NE'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NC*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'ES'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_ES*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'MS'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_MS*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else if (parameter_frame$region[i] == 'SW'){
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_mix*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }else{
      Cd_intake_one <- (parameter_frame$value[i]*parameter_frame$yield[i]+Cd_NW*abs(parameter_frame$net.output[i]))/parameter_frame$total.consumption[i]
    }
  }
  Cd_intake <- rbind(Cd_intake,Cd_intake_one)
}
Cd_intake_province <- as.data.frame(c('Beijing','Tianjin','Hebei','Shanxi','Neimenggu','Liaoning','Jilin','Heilongjiang',
                                      'Shanghai','Jiangsu','Zhejiang','Anhui','Fujian','Jiangxi','Shandong','Henan',
                                      'Hubei','Hunan','Guangdong','Guangxi','Hainan','Chongqing','Sichuan','Guizhou',
                                      'Yunnan','Xizang','Shannxi','Gansu','Qinghai','Ningxia','Xinjiang'))
Cd_intake <- cbind(Cd_intake_province,Cd_intake)
colnames(Cd_intake) <- c('province','intake_C')
write.csv(Cd_intake,'China predict/THQ计算参数/Wheat intake Cd concentration.csv', row.names=FALSE)
###健康危险指数
#HQ = (Ci*IR*EF*ED)/(BW*AT*RfD)
#Ci:稻米中的Cd含量(mg/Kg)
#IR：稻米摄入量(儿童/成年人 kg/d)
#EF:暴露频率(d/a)
#ED：暴露持续时间(儿童/成年人 9/45 a)
#BW:体重(儿童/成年人 kg)
#AT:平均时间(致癌：ED*365 d/a)
#RfD:口服剂量(mg/(kg d),)
EF = 350;ED_Adult=45;ED_Children=9
AT_Adult=45*365;AT_Children=9*365;RfD=1
setwd('D:/master/project ing/soil plant/paper')
parameter <- read.csv('China predict/THQ计算参数/Wheat parameter.csv')
#Adult
data_Adult <- as.data.frame((parameter$Cd*parameter$Adult.IR*EF*ED_Adult)/(parameter$Adult.WB*AT_Adult*RfD))
colnames(data_Adult) <- 'HQ'
data_Adult <- cbind(parameter$province,data_Adult)
colnames(data_Adult) <- c('Province','HQ')
write.csv(data_Adult,'China predict/THQ计算参数/Wheat Adult HQ.csv', row.names=FALSE)
#Children
data_Children <- as.data.frame((parameter$Cd*parameter$Children.IR*EF*ED_Children)/(parameter$Children.WB*AT_Children*RfD))
colnames(data_Children) <- 'HQ'
data_Children <- cbind(parameter$province,data_Children)
colnames(data_Children) <- c('Province','HQ')
write.csv(data_Children,'China predict/THQ计算参数/Wheat Children HQ.csv', row.names=FALSE)


###uncertainly analysis
setwd('D:/master/project ing/soil plant/paper')
label <- c(excel_sheets('grain model build/data_Cd.xlsx'))
output_wb <- createWorkbook()
for (i in 1:2){
  addWorksheet(output_wb,sheetName = label[i])
}
for (i in 1:2){
  #预测数据集
  final_data <- read.csv(paste0('China predict/SD Data/data_',label[i],'_average.csv'))
  map_data <- final_data[,1:3]##lat lon province
  predict_dataset <- final_data[,6:15]
  #建模数据集
  data <- read.xlsx('grain model build/data_Cd.xlsx', i)
  data <- data[,3:14]
  data <- data[,-c(11)]
  colnames(data)[length(data[1,])]<-'index'
  data$index<-as.numeric(data$index)
  ###建立模型，迭代200次
  for (random in 1:200){
    set.seed(random)
    rf <- randomForest(index~. , data = data, 
                       ntree=500,mtry=7,
                       proximity = F,
                       importance = F)
    predict_value <- as.data.frame(predict(rf, predict_dataset))
    map_data <- cbind(map_data, predict_value)
    print(random)
  }
  print(i)
  colnames(map_data) <- c('X','Y', 'Province', seq(1, 200, 1))
  ###cal uncertainty
  sample_mean <- as.data.frame(apply(map_data[,4:203], 1, mean))
  sample_sd <- as.data.frame(apply(map_data[,4:203], 1, sd))
  un <- abs(sample_sd/sample_mean)*100
  output <- cbind(final_data[,1:3], sample_mean, un)
  colnames(output) <- c('X', 'Y', 'Province', 'Value','Un')
  writeData(output_wb, sheet = i, output)
}
saveWorkbook(output_wb, "China predict/SD Data/uncertainly value.xlsx", overwrite = TRUE)
rice_un <- read.xlsx("China predict/SD Data/uncertainly value.xlsx",1)
rice_un <- rice_un[,-c(3,4)]
write.csv(rice_un,'China predict/SD Data/uncertainly value rice map.csv')
wheat_un <- read.xlsx("China predict/SD Data/uncertainly value.xlsx",2)
wheat_un <- wheat_un[,-c(3,4)]
write.csv(wheat_un,'China predict/SD Data/uncertainly value wheat map.csv')
















